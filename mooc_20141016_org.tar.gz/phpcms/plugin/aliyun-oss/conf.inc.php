<?php
//个人测试
//ACCESS_ID
define('OSS_ACCESS_ID', 'rV3092RYSnZyysV5');

//ACCESS_KEY
define('OSS_ACCESS_KEY', 'GppaQ2gws8WamehfMjpuAJ3UfSvslb');

//默认Bucket
define('OSS_DEFAULT_BUCKET', 'kpycms');
//签名超时设置(URL签名的有效时间)
define('OSS_SIGN_TIMEOUT', 180);

//是否记录日志
define('ALI_LOG', FALSE);

//自定义日志路径，如果没有设置，则使用系统默认路径，在./logs/
//define('ALI_LOG_PATH','');

//是否显示LOG输出
define('ALI_DISPLAY_LOG', FALSE);

//语言版本设置
define('ALI_LANG', 'zh');

