<?php 
defined('IN_PHPCMS') or exit('Access Denied');
defined('INSTALL') or exit('Access Denied');
$module = 'vote';
$modulename = '投票';
$introduce = '投票模块';
$author = 'phpcms team';
$authorsite = 'http://www.phpcms.cn';
$authoremail = 'phpcms@snda.com';
?>
