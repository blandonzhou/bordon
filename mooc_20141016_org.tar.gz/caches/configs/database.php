<?php

return array (
	'default' => array (
		'hostname' => 'rds7vrryyizubin.mysql.rds.aliyuncs.com',
		'database' => 'mooc',
		'username' => 'moocroot',
		'password' => 'ecnuyjy_1209',
		'tablepre' => 'v9_',
		'charset' => 'utf8',
		'type' => 'mysql',
		'debug' => true,
		'pconnect' => 0,
		'autoconnect' => 0
		),
);

?>
