<?php
return array (
  'caches/caches_model/caches_data/content_output.class.php' => 
  array (
    'func' => 
    array (
      0 => 
      array (
        0 => '_base64_decode(',
        1 => 'base64_decode',
      ),
      1 => 
      array (
        0 => '.base64_decode(',
        1 => 'base64_decode',
      ),
      2 => 
      array (
        0 => '_base64_decode(',
        1 => 'base64_decode',
      ),
    ),
  ),
  'caches/caches_model/caches_data/member_output.class.php' => 
  array (
    'func' => 
    array (
      0 => 
      array (
        0 => '_base64_decode(',
        1 => 'base64_decode',
      ),
      1 => 
      array (
        0 => '.base64_decode(',
        1 => 'base64_decode',
      ),
      2 => 
      array (
        0 => '_base64_decode(',
        1 => 'base64_decode',
      ),
    ),
  ),
  'caches/caches_scan/caches_data/scan_bad_file.cache.php' => 
  array (
    'func' => 
    array (
      0 => 
      array (
        0 => '_base64_decode(',
        1 => 'base64_decode',
      ),
      1 => 
      array (
        0 => '.base64_decode(',
        1 => 'base64_decode',
      ),
      2 => 
      array (
        0 => '_base64_decode(',
        1 => 'base64_decode',
      ),
      3 => 
      array (
        0 => '_base64_decode(',
        1 => 'base64_decode',
      ),
      4 => 
      array (
        0 => '.base64_decode(',
        1 => 'base64_decode',
      ),
      5 => 
      array (
        0 => '_base64_decode(',
        1 => 'base64_decode',
      ),
      6 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      7 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      8 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      9 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      10 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      11 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      12 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      13 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      14 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      15 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      16 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      17 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      18 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      19 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      20 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      21 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      22 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      23 => 
      array (
        0 => '
eval(',
        1 => 'eval',
      ),
      24 => 
      array (
        0 => '\'Eval(',
        1 => 'Eval',
      ),
      25 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      26 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      27 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      28 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      29 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      30 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      31 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      32 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      33 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      34 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      35 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      36 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      37 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      38 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      39 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      40 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      41 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      42 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      43 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      44 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      45 => 
      array (
        0 => '\'Eval(',
        1 => 'Eval',
      ),
      46 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      47 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      48 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      49 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      50 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      51 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      52 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      53 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      54 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      55 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      56 => 
      array (
        0 => ' com (',
        1 => 'com',
      ),
      57 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      58 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      59 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      60 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      61 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      62 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      63 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      64 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      65 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      66 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      67 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      68 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      69 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      70 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      71 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      72 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      73 => 
      array (
        0 => '\'eval(',
        1 => 'eval',
      ),
      74 => 
      array (
        0 => '\'eval(',
        1 => 'eval',
      ),
      75 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      76 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      77 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      78 => 
      array (
        0 => '\'eval(',
        1 => 'eval',
      ),
      79 => 
      array (
        0 => '\'eval(',
        1 => 'eval',
      ),
      80 => 
      array (
        0 => '=eval(',
        1 => 'eval',
      ),
      81 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      82 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      83 => 
      array (
        0 => ' eval(',
        1 => 'eval',
      ),
      84 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      85 => 
      array (
        0 => '\'Eval(',
        1 => 'Eval',
      ),
      86 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      87 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      88 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      89 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      90 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      91 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      92 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      93 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      94 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      95 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      96 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      97 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      98 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      99 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      100 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      101 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      102 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      103 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      104 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      105 => 
      array (
        0 => '\'Eval(',
        1 => 'Eval',
      ),
      106 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      107 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      108 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      109 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      110 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      111 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      112 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      113 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      114 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      115 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      116 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      117 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      118 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      119 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      120 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      121 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      122 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      123 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      124 => 
      array (
        0 => '\'Eval(',
        1 => 'Eval',
      ),
      125 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      126 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      127 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      128 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      129 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      130 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      131 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      132 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      133 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      134 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      135 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      136 => 
      array (
        0 => '\'Eval(',
        1 => 'Eval',
      ),
      137 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      138 => 
      array (
        0 => '\'eval(',
        1 => 'eval',
      ),
      139 => 
      array (
        0 => '
eval(',
        1 => 'eval',
      ),
      140 => 
      array (
        0 => ' eval(',
        1 => 'eval',
      ),
      141 => 
      array (
        0 => ' eval(',
        1 => 'eval',
      ),
      142 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      143 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      144 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      145 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      146 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      147 => 
      array (
        0 => ' base64_decode(',
        1 => 'base64_decode',
      ),
      148 => 
      array (
        0 => ' exec(',
        1 => 'exec',
      ),
      149 => 
      array (
        0 => '	exec(',
        1 => 'exec',
      ),
      150 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      151 => 
      array (
        0 => ' exec(',
        1 => 'exec',
      ),
      152 => 
      array (
        0 => '	exec(',
        1 => 'exec',
      ),
      153 => 
      array (
        0 => '	exec(',
        1 => 'exec',
      ),
      154 => 
      array (
        0 => ' exec(',
        1 => 'exec',
      ),
      155 => 
      array (
        0 => '	exec(',
        1 => 'exec',
      ),
      156 => 
      array (
        0 => '	exec(',
        1 => 'exec',
      ),
      157 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      158 => 
      array (
        0 => ' exec(',
        1 => 'exec',
      ),
      159 => 
      array (
        0 => '	exec(',
        1 => 'exec',
      ),
      160 => 
      array (
        0 => '	exec(',
        1 => 'exec',
      ),
      161 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      162 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      163 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      164 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      165 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      166 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      167 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      168 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      169 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      170 => 
      array (
        0 => ' eval(',
        1 => 'eval',
      ),
      171 => 
      array (
        0 => ' eval(',
        1 => 'eval',
      ),
      172 => 
      array (
        0 => '	eval(',
        1 => 'eval',
      ),
      173 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      174 => 
      array (
        0 => '\'eval(',
        1 => 'eval',
      ),
      175 => 
      array (
        0 => ' eval(',
        1 => 'eval',
      ),
      176 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      177 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      178 => 
      array (
        0 => '=eval(',
        1 => 'eval',
      ),
      179 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      180 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      181 => 
      array (
        0 => '=eval(',
        1 => 'eval',
      ),
      182 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      183 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      184 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      185 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      186 => 
      array (
        0 => ' eval(',
        1 => 'eval',
      ),
      187 => 
      array (
        0 => ' eval(',
        1 => 'eval',
      ),
      188 => 
      array (
        0 => ' eval(',
        1 => 'eval',
      ),
      189 => 
      array (
        0 => ' eval(',
        1 => 'eval',
      ),
      190 => 
      array (
        0 => '{eval(',
        1 => 'eval',
      ),
      191 => 
      array (
        0 => '{eval(',
        1 => 'eval',
      ),
      192 => 
      array (
        0 => '{eval(',
        1 => 'eval',
      ),
      193 => 
      array (
        0 => ' eval(',
        1 => 'eval',
      ),
      194 => 
      array (
        0 => ' eval(',
        1 => 'eval',
      ),
      195 => 
      array (
        0 => ' eval(',
        1 => 'eval',
      ),
      196 => 
      array (
        0 => ' eval(',
        1 => 'eval',
      ),
      197 => 
      array (
        0 => '
eval(',
        1 => 'eval',
      ),
      198 => 
      array (
        0 => ' eval(',
        1 => 'eval',
      ),
      199 => 
      array (
        0 => ' eval(',
        1 => 'eval',
      ),
      200 => 
      array (
        0 => ' eval(',
        1 => 'eval',
      ),
      201 => 
      array (
        0 => ' eval(',
        1 => 'eval',
      ),
      202 => 
      array (
        0 => '\'Eval(',
        1 => 'Eval',
      ),
      203 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      204 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      205 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      206 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      207 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      208 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      209 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      210 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      211 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      212 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      213 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      214 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      215 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      216 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      217 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      218 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      219 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      220 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      221 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      222 => 
      array (
        0 => '\'Eval(',
        1 => 'Eval',
      ),
      223 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      224 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      225 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      226 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      227 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      228 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      229 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      230 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      231 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      232 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      233 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      234 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      235 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      236 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      237 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      238 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      239 => 
      array (
        0 => '\'Eval(',
        1 => 'Eval',
      ),
      240 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      241 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      242 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      243 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      244 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      245 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      246 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      247 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      248 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      249 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      250 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      251 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      252 => 
      array (
        0 => '\'Eval(',
        1 => 'Eval',
      ),
      253 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      254 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      255 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      256 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      257 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      258 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      259 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      260 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      261 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      262 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      263 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      264 => 
      array (
        0 => ' eval(',
        1 => 'eval',
      ),
      265 => 
      array (
        0 => ' eval

(',
        1 => 'eval',
      ),
      266 => 
      array (
        0 => ' exec(',
        1 => 'exec',
      ),
      267 => 
      array (
        0 => ' exec(',
        1 => 'exec',
      ),
      268 => 
      array (
        0 => ' exec(',
        1 => 'exec',
      ),
      269 => 
      array (
        0 => ' exec(',
        1 => 'exec',
      ),
      270 => 
      array (
        0 => ' exec(',
        1 => 'exec',
      ),
      271 => 
      array (
        0 => ' exec(',
        1 => 'exec',
      ),
      272 => 
      array (
        0 => ' exec(',
        1 => 'exec',
      ),
      273 => 
      array (
        0 => ' exec(',
        1 => 'exec',
      ),
      274 => 
      array (
        0 => ' exec(',
        1 => 'exec',
      ),
      275 => 
      array (
        0 => ' exec(',
        1 => 'exec',
      ),
      276 => 
      array (
        0 => ' exec(',
        1 => 'exec',
      ),
      277 => 
      array (
        0 => ' exec(',
        1 => 'exec',
      ),
      278 => 
      array (
        0 => ' exec(',
        1 => 'exec',
      ),
      279 => 
      array (
        0 => ' exec(',
        1 => 'exec',
      ),
      280 => 
      array (
        0 => ' exec(',
        1 => 'exec',
      ),
      281 => 
      array (
        0 => ' exec(',
        1 => 'exec',
      ),
      282 => 
      array (
        0 => ' exec(',
        1 => 'exec',
      ),
      283 => 
      array (
        0 => ' eval(',
        1 => 'eval',
      ),
      284 => 
      array (
        0 => ' eval(',
        1 => 'eval',
      ),
      285 => 
      array (
        0 => ' eval(',
        1 => 'eval',
      ),
      286 => 
      array (
        0 => ' eval(',
        1 => 'eval',
      ),
      287 => 
      array (
        0 => ' eval(',
        1 => 'eval',
      ),
      288 => 
      array (
        0 => ' eval(',
        1 => 'eval',
      ),
      289 => 
      array (
        0 => ' eval(',
        1 => 'eval',
      ),
      290 => 
      array (
        0 => ' eval(',
        1 => 'eval',
      ),
      291 => 
      array (
        0 => ' eval(',
        1 => 'eval',
      ),
      292 => 
      array (
        0 => ' eval(',
        1 => 'eval',
      ),
      293 => 
      array (
        0 => ' com(',
        1 => 'com',
      ),
      294 => 
      array (
        0 => ' com(',
        1 => 'com',
      ),
      295 => 
      array (
        0 => ' eval(',
        1 => 'eval',
      ),
      296 => 
      array (
        0 => ' eval(',
        1 => 'eval',
      ),
      297 => 
      array (
        0 => '	eval(',
        1 => 'eval',
      ),
      298 => 
      array (
        0 => '	eval(',
        1 => 'eval',
      ),
      299 => 
      array (
        0 => '	eval(',
        1 => 'eval',
      ),
      300 => 
      array (
        0 => '	eval(',
        1 => 'eval',
      ),
      301 => 
      array (
        0 => ' eval(',
        1 => 'eval',
      ),
      302 => 
      array (
        0 => '	eval(',
        1 => 'eval',
      ),
      303 => 
      array (
        0 => ' base64_decode(',
        1 => 'base64_decode',
      ),
      304 => 
      array (
        0 => '@eval(',
        1 => 'eval',
      ),
      305 => 
      array (
        0 => ' base64_decode(',
        1 => 'base64_decode',
      ),
      306 => 
      array (
        0 => ' base64_decode(',
        1 => 'base64_decode',
      ),
      307 => 
      array (
        0 => ' base64_decode(',
        1 => 'base64_decode',
      ),
      308 => 
      array (
        0 => ' base64_decode(',
        1 => 'base64_decode',
      ),
      309 => 
      array (
        0 => ' base64_decode(',
        1 => 'base64_decode',
      ),
      310 => 
      array (
        0 => ' base64_decode(',
        1 => 'base64_decode',
      ),
      311 => 
      array (
        0 => ' base64_decode(',
        1 => 'base64_decode',
      ),
      312 => 
      array (
        0 => ' eval(',
        1 => 'eval',
      ),
      313 => 
      array (
        0 => '(eval(',
        1 => 'eval',
      ),
      314 => 
      array (
        0 => ' eval(',
        1 => 'eval',
      ),
      315 => 
      array (
        0 => '(eval(',
        1 => 'eval',
      ),
      316 => 
      array (
        0 => ' eval(',
        1 => 'eval',
      ),
      317 => 
      array (
        0 => '(eval(',
        1 => 'eval',
      ),
      318 => 
      array (
        0 => ' eval(',
        1 => 'eval',
      ),
      319 => 
      array (
        0 => '(eval(',
        1 => 'eval',
      ),
      320 => 
      array (
        0 => ' eval(',
        1 => 'eval',
      ),
      321 => 
      array (
        0 => '(eval(',
        1 => 'eval',
      ),
      322 => 
      array (
        0 => ' eval(',
        1 => 'eval',
      ),
      323 => 
      array (
        0 => '	eval(',
        1 => 'eval',
      ),
      324 => 
      array (
        0 => '(base64_decode(',
        1 => 'base64_decode',
      ),
      325 => 
      array (
        0 => '
exec(',
        1 => 'exec',
      ),
      326 => 
      array (
        0 => ' exec(',
        1 => 'exec',
      ),
      327 => 
      array (
        0 => ' exec(',
        1 => 'exec',
      ),
      328 => 
      array (
        0 => ' exec(',
        1 => 'exec',
      ),
      329 => 
      array (
        0 => ' exec(',
        1 => 'exec',
      ),
      330 => 
      array (
        0 => '_base64_decode(',
        1 => 'base64_decode',
      ),
      331 => 
      array (
        0 => '.base64_decode(',
        1 => 'base64_decode',
      ),
      332 => 
      array (
        0 => '_base64_decode(',
        1 => 'base64_decode',
      ),
      333 => 
      array (
        0 => ' exec(',
        1 => 'exec',
      ),
      334 => 
      array (
        0 => ' exec(',
        1 => 'exec',
      ),
      335 => 
      array (
        0 => ' exec(',
        1 => 'exec',
      ),
      336 => 
      array (
        0 => ' exec(',
        1 => 'exec',
      ),
      337 => 
      array (
        0 => '_exec(',
        1 => 'exec',
      ),
      338 => 
      array (
        0 => ' base64_decode(',
        1 => 'base64_decode',
      ),
      339 => 
      array (
        0 => ' base64_decode(',
        1 => 'base64_decode',
      ),
      340 => 
      array (
        0 => '_exec(',
        1 => 'exec',
      ),
      341 => 
      array (
        0 => ' base64_decode(',
        1 => 'base64_decode',
      ),
      342 => 
      array (
        0 => '_exec(',
        1 => 'exec',
      ),
      343 => 
      array (
        0 => '	exec(',
        1 => 'exec',
      ),
      344 => 
      array (
        0 => ' exec(',
        1 => 'exec',
      ),
      345 => 
      array (
        0 => '_base64_decode(',
        1 => 'base64_decode',
      ),
      346 => 
      array (
        0 => '.base64_decode(',
        1 => 'base64_decode',
      ),
      347 => 
      array (
        0 => '_base64_decode(',
        1 => 'base64_decode',
      ),
      348 => 
      array (
        0 => '_exec(',
        1 => 'exec',
      ),
      349 => 
      array (
        0 => '_exec(',
        1 => 'exec',
      ),
      350 => 
      array (
        0 => ' base64_decode(',
        1 => 'base64_decode',
      ),
      351 => 
      array (
        0 => ' base64_decode(',
        1 => 'base64_decode',
      ),
      352 => 
      array (
        0 => '(base64_decode(',
        1 => 'base64_decode',
      ),
      353 => 
      array (
        0 => '(base64_decode(',
        1 => 'base64_decode',
      ),
      354 => 
      array (
        0 => ' eval(',
        1 => 'eval',
      ),
      355 => 
      array (
        0 => ' eval(',
        1 => 'eval',
      ),
      356 => 
      array (
        0 => '\'system (',
        1 => 'system',
      ),
      357 => 
      array (
        0 => ' eval(',
        1 => 'eval',
      ),
      358 => 
      array (
        0 => ' eval(',
        1 => 'eval',
      ),
      359 => 
      array (
        0 => ' eval(',
        1 => 'eval',
      ),
      360 => 
      array (
        0 => ' eval(',
        1 => 'eval',
      ),
      361 => 
      array (
        0 => ' eval(',
        1 => 'eval',
      ),
      362 => 
      array (
        0 => ' eval(',
        1 => 'eval',
      ),
      363 => 
      array (
        0 => ' base64_decode(',
        1 => 'base64_decode',
      ),
      364 => 
      array (
        0 => '(base64_decode(',
        1 => 'base64_decode',
      ),
      365 => 
      array (
        0 => '(base64_decode(',
        1 => 'base64_decode',
      ),
      366 => 
      array (
        0 => ' base64_decode(',
        1 => 'base64_decode',
      ),
      367 => 
      array (
        0 => ',base64_decode(',
        1 => 'base64_decode',
      ),
      368 => 
      array (
        0 => ' base64_decode(',
        1 => 'base64_decode',
      ),
      369 => 
      array (
        0 => '(base64_decode(',
        1 => 'base64_decode',
      ),
      370 => 
      array (
        0 => '(base64_decode(',
        1 => 'base64_decode',
      ),
      371 => 
      array (
        0 => ' base64_decode(',
        1 => 'base64_decode',
      ),
      372 => 
      array (
        0 => ',base64_decode(',
        1 => 'base64_decode',
      ),
      373 => 
      array (
        0 => ' base64_decode(',
        1 => 'base64_decode',
      ),
      374 => 
      array (
        0 => '	exec(',
        1 => 'exec',
      ),
      375 => 
      array (
        0 => ' exec(',
        1 => 'exec',
      ),
      376 => 
      array (
        0 => '_exec(',
        1 => 'exec',
      ),
      377 => 
      array (
        0 => '(base64_decode(',
        1 => 'base64_decode',
      ),
      378 => 
      array (
        0 => ' eval(',
        1 => 'eval',
      ),
      379 => 
      array (
        0 => ' exec(',
        1 => 'exec',
      ),
      380 => 
      array (
        0 => '=base64_decode(',
        1 => 'base64_decode',
      ),
      381 => 
      array (
        0 => '\'Eval(',
        1 => 'Eval',
      ),
      382 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      383 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      384 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      385 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      386 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      387 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      388 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      389 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      390 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      391 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      392 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      393 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      394 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      395 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      396 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      397 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      398 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      399 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      400 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      401 => 
      array (
        0 => '\'Eval(',
        1 => 'Eval',
      ),
      402 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      403 => 
      array (
        0 => ' base64_decode(',
        1 => 'base64_decode',
      ),
      404 => 
      array (
        0 => '	eval(',
        1 => 'eval',
      ),
      405 => 
      array (
        0 => ' base64_decode(',
        1 => 'base64_decode',
      ),
      406 => 
      array (
        0 => '	eval(',
        1 => 'eval',
      ),
      407 => 
      array (
        0 => '	eval(',
        1 => 'eval',
      ),
      408 => 
      array (
        0 => ' base64_decode(',
        1 => 'base64_decode',
      ),
      409 => 
      array (
        0 => '	eval(',
        1 => 'eval',
      ),
      410 => 
      array (
        0 => ' eval(',
        1 => 'eval',
      ),
      411 => 
      array (
        0 => ' eval(',
        1 => 'eval',
      ),
      412 => 
      array (
        0 => '	eval(',
        1 => 'eval',
      ),
      413 => 
      array (
        0 => '	eval(',
        1 => 'eval',
      ),
      414 => 
      array (
        0 => ' base64_decode(',
        1 => 'base64_decode',
      ),
      415 => 
      array (
        0 => ' eval(',
        1 => 'eval',
      ),
      416 => 
      array (
        0 => ' eval(',
        1 => 'eval',
      ),
      417 => 
      array (
        0 => '\'system (',
        1 => 'system',
      ),
      418 => 
      array (
        0 => ' eval(',
        1 => 'eval',
      ),
      419 => 
      array (
        0 => ' eval(',
        1 => 'eval',
      ),
      420 => 
      array (
        0 => ' eval(',
        1 => 'eval',
      ),
      421 => 
      array (
        0 => ' eval(',
        1 => 'eval',
      ),
      422 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      423 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      424 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      425 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      426 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      427 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      428 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      429 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      430 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      431 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      432 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      433 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      434 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      435 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      436 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      437 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      438 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      439 => 
      array (
        0 => '
eval(',
        1 => 'eval',
      ),
      440 => 
      array (
        0 => '\'Eval(',
        1 => 'Eval',
      ),
      441 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      442 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      443 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      444 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      445 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      446 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      447 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      448 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      449 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      450 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      451 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      452 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      453 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      454 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      455 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      456 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      457 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      458 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      459 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      460 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      461 => 
      array (
        0 => '\'Eval(',
        1 => 'Eval',
      ),
      462 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      463 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      464 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      465 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      466 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      467 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      468 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      469 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      470 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      471 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      472 => 
      array (
        0 => ' com (',
        1 => 'com',
      ),
      473 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      474 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      475 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      476 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      477 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      478 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      479 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      480 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      481 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      482 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      483 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      484 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      485 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      486 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      487 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      488 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      489 => 
      array (
        0 => '\'eval(',
        1 => 'eval',
      ),
      490 => 
      array (
        0 => '\'eval(',
        1 => 'eval',
      ),
      491 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      492 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      493 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      494 => 
      array (
        0 => '\'eval(',
        1 => 'eval',
      ),
      495 => 
      array (
        0 => '\'eval(',
        1 => 'eval',
      ),
      496 => 
      array (
        0 => '=eval(',
        1 => 'eval',
      ),
      497 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      498 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      499 => 
      array (
        0 => ' eval(',
        1 => 'eval',
      ),
      500 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      501 => 
      array (
        0 => '\'Eval(',
        1 => 'Eval',
      ),
      502 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      503 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      504 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      505 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      506 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      507 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      508 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      509 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      510 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      511 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      512 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      513 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      514 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      515 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      516 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      517 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      518 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      519 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      520 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      521 => 
      array (
        0 => '\'Eval(',
        1 => 'Eval',
      ),
      522 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      523 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      524 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      525 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      526 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      527 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      528 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      529 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      530 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      531 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      532 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      533 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      534 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      535 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      536 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      537 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      538 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      539 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      540 => 
      array (
        0 => '\'Eval(',
        1 => 'Eval',
      ),
      541 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      542 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      543 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      544 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      545 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      546 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      547 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      548 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      549 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      550 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      551 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      552 => 
      array (
        0 => '\'Eval(',
        1 => 'Eval',
      ),
      553 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      554 => 
      array (
        0 => '\'eval(',
        1 => 'eval',
      ),
      555 => 
      array (
        0 => '
eval(',
        1 => 'eval',
      ),
      556 => 
      array (
        0 => ' eval(',
        1 => 'eval',
      ),
      557 => 
      array (
        0 => ' eval(',
        1 => 'eval',
      ),
      558 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      559 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      560 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      561 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      562 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      563 => 
      array (
        0 => ' base64_decode(',
        1 => 'base64_decode',
      ),
      564 => 
      array (
        0 => ' exec(',
        1 => 'exec',
      ),
      565 => 
      array (
        0 => '	exec(',
        1 => 'exec',
      ),
      566 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      567 => 
      array (
        0 => ' exec(',
        1 => 'exec',
      ),
      568 => 
      array (
        0 => '	exec(',
        1 => 'exec',
      ),
      569 => 
      array (
        0 => '	exec(',
        1 => 'exec',
      ),
      570 => 
      array (
        0 => ' exec(',
        1 => 'exec',
      ),
      571 => 
      array (
        0 => '	exec(',
        1 => 'exec',
      ),
      572 => 
      array (
        0 => '	exec(',
        1 => 'exec',
      ),
      573 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      574 => 
      array (
        0 => ' exec(',
        1 => 'exec',
      ),
      575 => 
      array (
        0 => '	exec(',
        1 => 'exec',
      ),
      576 => 
      array (
        0 => '	exec(',
        1 => 'exec',
      ),
      577 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      578 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      579 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      580 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      581 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      582 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      583 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      584 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      585 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      586 => 
      array (
        0 => ' eval(',
        1 => 'eval',
      ),
      587 => 
      array (
        0 => ' eval(',
        1 => 'eval',
      ),
      588 => 
      array (
        0 => '	eval(',
        1 => 'eval',
      ),
      589 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      590 => 
      array (
        0 => '\'eval(',
        1 => 'eval',
      ),
      591 => 
      array (
        0 => ' eval(',
        1 => 'eval',
      ),
      592 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      593 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      594 => 
      array (
        0 => '=eval(',
        1 => 'eval',
      ),
      595 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      596 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      597 => 
      array (
        0 => '=eval(',
        1 => 'eval',
      ),
      598 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      599 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      600 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      601 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      602 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      603 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      604 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      605 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      606 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      607 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      608 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      609 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      610 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      611 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      612 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      613 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      614 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      615 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      616 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      617 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      618 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      619 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      620 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      621 => 
      array (
        0 => '\'Eval(',
        1 => 'Eval',
      ),
      622 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      623 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      624 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      625 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      626 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      627 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      628 => 
      array (
        0 => '\'Eval(',
        1 => 'Eval',
      ),
      629 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      630 => 
      array (
        0 => ' eval(',
        1 => 'eval',
      ),
      631 => 
      array (
        0 => ' eval(',
        1 => 'eval',
      ),
      632 => 
      array (
        0 => ' eval(',
        1 => 'eval',
      ),
      633 => 
      array (
        0 => ' eval(',
        1 => 'eval',
      ),
      634 => 
      array (
        0 => '{eval(',
        1 => 'eval',
      ),
      635 => 
      array (
        0 => '{eval(',
        1 => 'eval',
      ),
      636 => 
      array (
        0 => '{eval(',
        1 => 'eval',
      ),
      637 => 
      array (
        0 => ' eval(',
        1 => 'eval',
      ),
      638 => 
      array (
        0 => ' eval(',
        1 => 'eval',
      ),
      639 => 
      array (
        0 => ' eval(',
        1 => 'eval',
      ),
      640 => 
      array (
        0 => ' eval(',
        1 => 'eval',
      ),
      641 => 
      array (
        0 => '
eval(',
        1 => 'eval',
      ),
      642 => 
      array (
        0 => ' eval(',
        1 => 'eval',
      ),
      643 => 
      array (
        0 => ' eval(',
        1 => 'eval',
      ),
      644 => 
      array (
        0 => ' eval(',
        1 => 'eval',
      ),
      645 => 
      array (
        0 => ' eval(',
        1 => 'eval',
      ),
      646 => 
      array (
        0 => '\'Eval(',
        1 => 'Eval',
      ),
      647 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      648 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      649 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      650 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      651 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      652 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      653 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      654 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      655 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      656 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      657 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      658 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      659 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      660 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      661 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      662 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      663 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      664 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      665 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      666 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      667 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      668 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      669 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      670 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      671 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      672 => 
      array (
        0 => '\'Eval(',
        1 => 'Eval',
      ),
      673 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      674 => 
      array (
        0 => ' eval(',
        1 => 'eval',
      ),
      675 => 
      array (
        0 => ' eval(',
        1 => 'eval',
      ),
      676 => 
      array (
        0 => ' eval(',
        1 => 'eval',
      ),
      677 => 
      array (
        0 => '\'Eval(',
        1 => 'Eval',
      ),
      678 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      679 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      680 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      681 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      682 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      683 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      684 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      685 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      686 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      687 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      688 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      689 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      690 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      691 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      692 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      693 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      694 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      695 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      696 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      697 => 
      array (
        0 => '\'Eval(',
        1 => 'Eval',
      ),
      698 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      699 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      700 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      701 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      702 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      703 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      704 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      705 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      706 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      707 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      708 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      709 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      710 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      711 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      712 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      713 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      714 => 
      array (
        0 => '\'Eval(',
        1 => 'Eval',
      ),
      715 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      716 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      717 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      718 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      719 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      720 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      721 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      722 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      723 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      724 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      725 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      726 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      727 => 
      array (
        0 => '\'Eval(',
        1 => 'Eval',
      ),
      728 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      729 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      730 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      731 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      732 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      733 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      734 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      735 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      736 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      737 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      738 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      739 => 
      array (
        0 => '\'Eval(',
        1 => 'Eval',
      ),
      740 => 
      array (
        0 => '\'Eval(',
        1 => 'Eval',
      ),
      741 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      742 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      743 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      744 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      745 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      746 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      747 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      748 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      749 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      750 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      751 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      752 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      753 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      754 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      755 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      756 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      757 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      758 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      759 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      760 => 
      array (
        0 => '\'Eval(',
        1 => 'Eval',
      ),
      761 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      762 => 
      array (
        0 => ' exec(',
        1 => 'exec',
      ),
      763 => 
      array (
        0 => ' exec(',
        1 => 'exec',
      ),
      764 => 
      array (
        0 => ' base64_decode(',
        1 => 'base64_decode',
      ),
    ),
  ),
  'caches/caches_template/mooc/content/index.php' => 
  array (
    'func' => 
    array (
      0 => 
      array (
        0 => ' eval(',
        1 => 'eval',
      ),
      1 => 
      array (
        0 => ' eval

(',
        1 => 'eval',
      ),
    ),
  ),
  'caches/error_log.php' => 
  array (
    'func' => 
    array (
      0 => 
      array (
        0 => ' exec(',
        1 => 'exec',
      ),
      1 => 
      array (
        0 => ' exec(',
        1 => 'exec',
      ),
      2 => 
      array (
        0 => ' exec(',
        1 => 'exec',
      ),
      3 => 
      array (
        0 => ' exec(',
        1 => 'exec',
      ),
      4 => 
      array (
        0 => ' exec(',
        1 => 'exec',
      ),
      5 => 
      array (
        0 => ' exec(',
        1 => 'exec',
      ),
      6 => 
      array (
        0 => ' exec(',
        1 => 'exec',
      ),
      7 => 
      array (
        0 => ' exec(',
        1 => 'exec',
      ),
      8 => 
      array (
        0 => ' exec(',
        1 => 'exec',
      ),
      9 => 
      array (
        0 => ' exec(',
        1 => 'exec',
      ),
      10 => 
      array (
        0 => ' exec(',
        1 => 'exec',
      ),
      11 => 
      array (
        0 => ' exec(',
        1 => 'exec',
      ),
      12 => 
      array (
        0 => ' exec(',
        1 => 'exec',
      ),
      13 => 
      array (
        0 => ' exec(',
        1 => 'exec',
      ),
      14 => 
      array (
        0 => ' exec(',
        1 => 'exec',
      ),
      15 => 
      array (
        0 => ' exec(',
        1 => 'exec',
      ),
      16 => 
      array (
        0 => ' exec(',
        1 => 'exec',
      ),
    ),
  ),
  'caches/poster_js/1.js' => 
  array (
    'func' => 
    array (
      0 => 
      array (
        0 => ' eval(',
        1 => 'eval',
      ),
    ),
  ),
  'caches/poster_js/10.js' => 
  array (
    'func' => 
    array (
      0 => 
      array (
        0 => ' eval(',
        1 => 'eval',
      ),
    ),
  ),
  'caches/poster_js/12.js' => 
  array (
    'func' => 
    array (
      0 => 
      array (
        0 => ' eval(',
        1 => 'eval',
      ),
    ),
  ),
  'caches/poster_js/2.js' => 
  array (
    'func' => 
    array (
      0 => 
      array (
        0 => ' eval(',
        1 => 'eval',
      ),
    ),
  ),
  'caches/poster_js/3.js' => 
  array (
    'func' => 
    array (
      0 => 
      array (
        0 => ' eval(',
        1 => 'eval',
      ),
    ),
  ),
  'caches/poster_js/4.js' => 
  array (
    'func' => 
    array (
      0 => 
      array (
        0 => ' eval(',
        1 => 'eval',
      ),
    ),
  ),
  'caches/poster_js/5.js' => 
  array (
    'func' => 
    array (
      0 => 
      array (
        0 => ' eval(',
        1 => 'eval',
      ),
    ),
  ),
  'caches/poster_js/6.js' => 
  array (
    'func' => 
    array (
      0 => 
      array (
        0 => ' eval(',
        1 => 'eval',
      ),
    ),
  ),
  'caches/poster_js/7.js' => 
  array (
    'func' => 
    array (
      0 => 
      array (
        0 => ' eval(',
        1 => 'eval',
      ),
    ),
  ),
  'caches/poster_js/8.js' => 
  array (
    'func' => 
    array (
      0 => 
      array (
        0 => ' eval(',
        1 => 'eval',
      ),
    ),
  ),
  'phpcms/libs/classes/access.class.php' => 
  array (
    'func' => 
    array (
      0 => 
      array (
        0 => ' com(',
        1 => 'com',
      ),
    ),
  ),
  'phpcms/libs/classes/db_access.class.php' => 
  array (
    'func' => 
    array (
      0 => 
      array (
        0 => ' com(',
        1 => 'com',
      ),
    ),
  ),
  'phpcms/libs/classes/tree.class.php' => 
  array (
    'func' => 
    array (
      0 => 
      array (
        0 => ' eval(',
        1 => 'eval',
      ),
      1 => 
      array (
        0 => ' eval(',
        1 => 'eval',
      ),
      2 => 
      array (
        0 => '	eval(',
        1 => 'eval',
      ),
      3 => 
      array (
        0 => '	eval(',
        1 => 'eval',
      ),
      4 => 
      array (
        0 => '	eval(',
        1 => 'eval',
      ),
      5 => 
      array (
        0 => '	eval(',
        1 => 'eval',
      ),
      6 => 
      array (
        0 => ' eval(',
        1 => 'eval',
      ),
      7 => 
      array (
        0 => '	eval(',
        1 => 'eval',
      ),
    ),
  ),
  'phpcms/libs/functions/autoload/plugin.func.php' => 
  array (
    'func' => 
    array (
      0 => 
      array (
        0 => ' base64_decode(',
        1 => 'base64_decode',
      ),
    ),
  ),
  'phpcms/libs/functions/global.func.php' => 
  array (
    'func' => 
    array (
      0 => 
      array (
        0 => '@eval(',
        1 => 'eval',
      ),
      1 => 
      array (
        0 => ' base64_decode(',
        1 => 'base64_decode',
      ),
    ),
  ),
  'phpcms/modules/admin/classes/card.class.php' => 
  array (
    'func' => 
    array (
      0 => 
      array (
        0 => ' base64_decode(',
        1 => 'base64_decode',
      ),
    ),
  ),
  'phpcms/modules/admin/functions/admin.func.php' => 
  array (
    'func' => 
    array (
      0 => 
      array (
        0 => ' base64_decode(',
        1 => 'base64_decode',
      ),
    ),
  ),
  'phpcms/modules/admin/index.php' => 
  array (
    'func' => 
    array (
      0 => 
      array (
        0 => ' base64_decode(',
        1 => 'base64_decode',
      ),
      1 => 
      array (
        0 => ' base64_decode(',
        1 => 'base64_decode',
      ),
      2 => 
      array (
        0 => ' base64_decode(',
        1 => 'base64_decode',
      ),
      3 => 
      array (
        0 => ' base64_decode(',
        1 => 'base64_decode',
      ),
    ),
  ),
  'phpcms/modules/admin/templates/info_setting.tpl.php' => 
  array (
    'func' => 
    array (
      0 => 
      array (
        0 => ' eval(',
        1 => 'eval',
      ),
    ),
  ),
  'phpcms/modules/admin/templates/role_priv.tpl.php' => 
  array (
    'func' => 
    array (
      0 => 
      array (
        0 => '(eval(',
        1 => 'eval',
      ),
      1 => 
      array (
        0 => ' eval(',
        1 => 'eval',
      ),
      2 => 
      array (
        0 => '(eval(',
        1 => 'eval',
      ),
      3 => 
      array (
        0 => ' eval(',
        1 => 'eval',
      ),
      4 => 
      array (
        0 => '(eval(',
        1 => 'eval',
      ),
      5 => 
      array (
        0 => ' eval(',
        1 => 'eval',
      ),
      6 => 
      array (
        0 => '(eval(',
        1 => 'eval',
      ),
      7 => 
      array (
        0 => ' eval(',
        1 => 'eval',
      ),
      8 => 
      array (
        0 => '(eval(',
        1 => 'eval',
      ),
      9 => 
      array (
        0 => ' eval(',
        1 => 'eval',
      ),
    ),
  ),
  'phpcms/modules/block/templates/block_update.tpl.php' => 
  array (
    'func' => 
    array (
      0 => 
      array (
        0 => '	eval(',
        1 => 'eval',
      ),
    ),
  ),
  'phpcms/modules/collection/node.php' => 
  array (
    'func' => 
    array (
      0 => 
      array (
        0 => '(base64_decode(',
        1 => 'base64_decode',
      ),
    ),
  ),
  'phpcms/modules/content/add.php' => 
  array (
    'func' => 
    array (
      0 => 
      array (
        0 => '
exec(',
        1 => 'exec',
      ),
    ),
  ),
  'phpcms/modules/content/content.php' => 
  array (
    'func' => 
    array (
      0 => 
      array (
        0 => ' exec(',
        1 => 'exec',
      ),
      1 => 
      array (
        0 => ' exec(',
        1 => 'exec',
      ),
      2 => 
      array (
        0 => ' exec(',
        1 => 'exec',
      ),
      3 => 
      array (
        0 => ' exec(',
        1 => 'exec',
      ),
    ),
  ),
  'phpcms/modules/content/fields/editor/output.inc.php' => 
  array (
    'func' => 
    array (
      0 => 
      array (
        0 => '_base64_decode(',
        1 => 'base64_decode',
      ),
      1 => 
      array (
        0 => '.base64_decode(',
        1 => 'base64_decode',
      ),
      2 => 
      array (
        0 => '_base64_decode(',
        1 => 'base64_decode',
      ),
    ),
  ),
  'phpcms/modules/content/sakai.php' => 
  array (
    'func' => 
    array (
      0 => 
      array (
        0 => ' exec(',
        1 => 'exec',
      ),
      1 => 
      array (
        0 => ' exec(',
        1 => 'exec',
      ),
      2 => 
      array (
        0 => ' exec(',
        1 => 'exec',
      ),
      3 => 
      array (
        0 => ' exec(',
        1 => 'exec',
      ),
    ),
  ),
  'phpcms/modules/member/classes/OauthSDK.class.php' => 
  array (
    'func' => 
    array (
      0 => 
      array (
        0 => '_exec(',
        1 => 'exec',
      ),
    ),
  ),
  'phpcms/modules/member/classes/client.class.php' => 
  array (
    'func' => 
    array (
      0 => 
      array (
        0 => ' base64_decode(',
        1 => 'base64_decode',
      ),
    ),
  ),
  'phpcms/modules/member/classes/qqoauth.class.php' => 
  array (
    'func' => 
    array (
      0 => 
      array (
        0 => ' base64_decode(',
        1 => 'base64_decode',
      ),
      1 => 
      array (
        0 => '_exec(',
        1 => 'exec',
      ),
    ),
  ),
  'phpcms/modules/member/classes/weibooauth.class.php' => 
  array (
    'func' => 
    array (
      0 => 
      array (
        0 => ' base64_decode(',
        1 => 'base64_decode',
      ),
      1 => 
      array (
        0 => '_exec(',
        1 => 'exec',
      ),
    ),
  ),
  'phpcms/modules/member/content.php' => 
  array (
    'func' => 
    array (
      0 => 
      array (
        0 => '	exec(',
        1 => 'exec',
      ),
      1 => 
      array (
        0 => ' exec(',
        1 => 'exec',
      ),
    ),
  ),
  'phpcms/modules/member/fields/editor/output.inc.php' => 
  array (
    'func' => 
    array (
      0 => 
      array (
        0 => '_base64_decode(',
        1 => 'base64_decode',
      ),
      1 => 
      array (
        0 => '.base64_decode(',
        1 => 'base64_decode',
      ),
      2 => 
      array (
        0 => '_base64_decode(',
        1 => 'base64_decode',
      ),
    ),
  ),
  'phpcms/modules/member/functions/utils.func.php' => 
  array (
    'func' => 
    array (
      0 => 
      array (
        0 => '_exec(',
        1 => 'exec',
      ),
      1 => 
      array (
        0 => '_exec(',
        1 => 'exec',
      ),
    ),
  ),
  'phpcms/modules/sms/functions/global.func.php' => 
  array (
    'func' => 
    array (
      0 => 
      array (
        0 => ' base64_decode(',
        1 => 'base64_decode',
      ),
      1 => 
      array (
        0 => ' base64_decode(',
        1 => 'base64_decode',
      ),
    ),
  ),
  'phpcms/modules/template/style.php' => 
  array (
    'func' => 
    array (
      0 => 
      array (
        0 => '(base64_decode(',
        1 => 'base64_decode',
      ),
      1 => 
      array (
        0 => '(base64_decode(',
        1 => 'base64_decode',
      ),
    ),
  ),
  'phpcms/modules/upgrade/classes/pclzip.class.php' => 
  array (
    'func' => 
    array (
      0 => 
      array (
        0 => ' eval(',
        1 => 'eval',
      ),
      1 => 
      array (
        0 => ' eval(',
        1 => 'eval',
      ),
      2 => 
      array (
        0 => 'system (',
        1 => 'system',
      ),
      3 => 
      array (
        0 => ' eval(',
        1 => 'eval',
      ),
      4 => 
      array (
        0 => ' eval(',
        1 => 'eval',
      ),
      5 => 
      array (
        0 => ' eval(',
        1 => 'eval',
      ),
      6 => 
      array (
        0 => ' eval(',
        1 => 'eval',
      ),
      7 => 
      array (
        0 => ' eval(',
        1 => 'eval',
      ),
      8 => 
      array (
        0 => ' eval(',
        1 => 'eval',
      ),
    ),
  ),
  'phpcms/modules/upgrade/templates/check_file.tpl.php' => 
  array (
    'func' => 
    array (
      0 => 
      array (
        0 => ' base64_decode(',
        1 => 'base64_decode',
      ),
      1 => 
      array (
        0 => '(base64_decode(',
        1 => 'base64_decode',
      ),
      2 => 
      array (
        0 => '(base64_decode(',
        1 => 'base64_decode',
      ),
      3 => 
      array (
        0 => ' base64_decode(',
        1 => 'base64_decode',
      ),
      4 => 
      array (
        0 => ',base64_decode(',
        1 => 'base64_decode',
      ),
      5 => 
      array (
        0 => ' base64_decode(',
        1 => 'base64_decode',
      ),
      6 => 
      array (
        0 => '(base64_decode(',
        1 => 'base64_decode',
      ),
      7 => 
      array (
        0 => '(base64_decode(',
        1 => 'base64_decode',
      ),
      8 => 
      array (
        0 => ' base64_decode(',
        1 => 'base64_decode',
      ),
      9 => 
      array (
        0 => ',base64_decode(',
        1 => 'base64_decode',
      ),
      10 => 
      array (
        0 => ' base64_decode(',
        1 => 'base64_decode',
      ),
    ),
  ),
  'phpcms/modules/video/batch_upload.php' => 
  array (
    'func' => 
    array (
      0 => 
      array (
        0 => '	exec(',
        1 => 'exec',
      ),
      1 => 
      array (
        0 => ' exec(',
        1 => 'exec',
      ),
    ),
  ),
  'phpcms/modules/video/classes/ku6api.class.php' => 
  array (
    'func' => 
    array (
      0 => 
      array (
        0 => '_exec(',
        1 => 'exec',
      ),
    ),
  ),
  'phpcms/modules/video/classes/xxtea.class.php' => 
  array (
    'func' => 
    array (
      0 => 
      array (
        0 => '(base64_decode(',
        1 => 'base64_decode',
      ),
    ),
  ),
  'phpcms/modules/video/templates/video_list.tpl.php' => 
  array (
    'func' => 
    array (
      0 => 
      array (
        0 => ' eval(',
        1 => 'eval',
      ),
    ),
  ),
  'phpcms/modules/video/video.php' => 
  array (
    'func' => 
    array (
      0 => 
      array (
        0 => ' exec(',
        1 => 'exec',
      ),
    ),
  ),
  'phpcms/modules/wap/index.php' => 
  array (
    'func' => 
    array (
      0 => 
      array (
        0 => '=base64_decode(',
        1 => 'base64_decode',
      ),
    ),
  ),
  'phpcms/templates/mooc/images/jquery.min.js' => 
  array (
    'func' => 
    array (
      0 => 
      array (
        0 => 'Eval(',
        1 => 'Eval',
      ),
      1 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      2 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      3 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      4 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      5 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      6 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      7 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      8 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      9 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      10 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      11 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      12 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      13 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      14 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      15 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      16 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      17 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      18 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      19 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      20 => 
      array (
        0 => 'Eval(',
        1 => 'Eval',
      ),
      21 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
    ),
  ),
  'phpsso_server/api/uc.php' => 
  array (
    'func' => 
    array (
      0 => 
      array (
        0 => ' base64_decode(',
        1 => 'base64_decode',
      ),
    ),
  ),
  'phpsso_server/api/uc_client/client.php' => 
  array (
    'func' => 
    array (
      0 => 
      array (
        0 => '	eval(',
        1 => 'eval',
      ),
      1 => 
      array (
        0 => ' base64_decode(',
        1 => 'base64_decode',
      ),
    ),
  ),
  'phpsso_server/api/uc_client/model/base.php' => 
  array (
    'func' => 
    array (
      0 => 
      array (
        0 => '	eval(',
        1 => 'eval',
      ),
    ),
  ),
  'phpsso_server/api/uc_client_1_5/client.php' => 
  array (
    'func' => 
    array (
      0 => 
      array (
        0 => '	eval(',
        1 => 'eval',
      ),
      1 => 
      array (
        0 => ' base64_decode(',
        1 => 'base64_decode',
      ),
    ),
  ),
  'phpsso_server/api/uc_client_1_5/model/base.php' => 
  array (
    'func' => 
    array (
      0 => 
      array (
        0 => '	eval(',
        1 => 'eval',
      ),
    ),
  ),
  'phpsso_server/phpcms/libs/classes/tree.class.php' => 
  array (
    'func' => 
    array (
      0 => 
      array (
        0 => ' eval(',
        1 => 'eval',
      ),
      1 => 
      array (
        0 => ' eval(',
        1 => 'eval',
      ),
      2 => 
      array (
        0 => '	eval(',
        1 => 'eval',
      ),
    ),
  ),
  'phpsso_server/phpcms/libs/functions/global.func.php' => 
  array (
    'func' => 
    array (
      0 => 
      array (
        0 => '	eval(',
        1 => 'eval',
      ),
      1 => 
      array (
        0 => ' base64_decode(',
        1 => 'base64_decode',
      ),
    ),
  ),
  'phpsso_server/phpcms/modules/phpsso/classes/pclzip.class.php' => 
  array (
    'func' => 
    array (
      0 => 
      array (
        0 => ' eval(',
        1 => 'eval',
      ),
      1 => 
      array (
        0 => ' eval(',
        1 => 'eval',
      ),
      2 => 
      array (
        0 => 'system (',
        1 => 'system',
      ),
      3 => 
      array (
        0 => ' eval(',
        1 => 'eval',
      ),
      4 => 
      array (
        0 => ' eval(',
        1 => 'eval',
      ),
      5 => 
      array (
        0 => ' eval(',
        1 => 'eval',
      ),
      6 => 
      array (
        0 => ' eval(',
        1 => 'eval',
      ),
    ),
  ),
  'phpsso_server/statics/js/ckeditor/ckeditor.js' => 
  array (
    'func' => 
    array (
      0 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      1 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      2 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      3 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      4 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
    ),
  ),
  'phpsso_server/statics/js/ckeditor/plugins/link/dialogs/link.js' => 
  array (
    'func' => 
    array (
      0 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      1 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
    ),
  ),
  'phpsso_server/statics/js/ckeditor/plugins/table/dialogs/table.js' => 
  array (
    'func' => 
    array (
      0 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      1 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      2 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
    ),
  ),
  'phpsso_server/statics/js/ckeditor/plugins/tabletools/dialogs/tableCell.js' => 
  array (
    'func' => 
    array (
      0 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
    ),
  ),
  'phpsso_server/statics/js/ckeditor/plugins/uicolor/yui/yui.js' => 
  array (
    'func' => 
    array (
      0 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      1 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      2 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      3 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      4 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      5 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
    ),
  ),
  'phpsso_server/statics/js/formvalidator.js' => 
  array (
    'func' => 
    array (
      0 => 
      array (
        0 => '
eval(',
        1 => 'eval',
      ),
    ),
  ),
  'phpsso_server/statics/js/jquery.min.js' => 
  array (
    'func' => 
    array (
      0 => 
      array (
        0 => 'Eval(',
        1 => 'Eval',
      ),
      1 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      2 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      3 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      4 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      5 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      6 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      7 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      8 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      9 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      10 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      11 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      12 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      13 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      14 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      15 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      16 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      17 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      18 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      19 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      20 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      21 => 
      array (
        0 => 'Eval(',
        1 => 'Eval',
      ),
      22 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
    ),
  ),
  'phpsso_server/statics/js/swfobject.js' => 
  array (
    'func' => 
    array (
      0 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
    ),
  ),
  'statics/js/calendar/calendar.js' => 
  array (
    'func' => 
    array (
      0 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      1 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
    ),
  ),
  'statics/js/ckeditor/ckeditor.js' => 
  array (
    'func' => 
    array (
      0 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      1 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      2 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      3 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      4 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      5 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
    ),
  ),
  'statics/js/ckeditor/lang/pt-br.js' => 
  array (
    'func' => 
    array (
      0 => 
      array (
        0 => ' com (',
        1 => 'com',
      ),
    ),
  ),
  'statics/js/ckeditor/plugins/adobeair/plugin.js' => 
  array (
    'func' => 
    array (
      0 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
    ),
  ),
  'statics/js/ckeditor/plugins/bbcode/plugin.js' => 
  array (
    'func' => 
    array (
      0 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
    ),
  ),
  'statics/js/ckeditor/plugins/link/dialogs/link.js' => 
  array (
    'func' => 
    array (
      0 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      1 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
    ),
  ),
  'statics/js/ckeditor/plugins/pastefromword/filter/default.js' => 
  array (
    'func' => 
    array (
      0 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      1 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      2 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
    ),
  ),
  'statics/js/ckeditor/plugins/scayt/dialogs/options.js' => 
  array (
    'func' => 
    array (
      0 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
    ),
  ),
  'statics/js/ckeditor/plugins/tabletools/dialogs/tableCell.js' => 
  array (
    'func' => 
    array (
      0 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
    ),
  ),
  'statics/js/ckeditor/plugins/uicolor/yui/yui.js' => 
  array (
    'func' => 
    array (
      0 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      1 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      2 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      3 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      4 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      5 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
    ),
  ),
  'statics/js/ckplayer/ckplayer.js' => 
  array (
    'func' => 
    array (
      0 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
    ),
  ),
  'statics/js/cookie.js' => 
  array (
    'func' => 
    array (
      0 => 
      array (
        0 => 'eval(',
        1 => 'eval',
      ),
      1 => 
      array (
        0 => 'eval(',
        1 => 'eval',
      ),
    ),
  ),
  'statics/js/crop/swfobject.js' => 
  array (
    'func' => 
    array (
      0 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
    ),
  ),
  'statics/js/dialog.js' => 
  array (
    'func' => 
    array (
      0 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      1 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      2 => 
      array (
        0 => '\'eval(',
        1 => 'eval',
      ),
      3 => 
      array (
        0 => '\'eval(',
        1 => 'eval',
      ),
    ),
  ),
  'statics/js/formvalidator.js' => 
  array (
    'func' => 
    array (
      0 => 
      array (
        0 => '=eval(',
        1 => 'eval',
      ),
    ),
  ),
  'statics/js/html5.js' => 
  array (
    'func' => 
    array (
      0 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      1 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
    ),
  ),
  'statics/js/jqplot/jquery.jqplot.js' => 
  array (
    'func' => 
    array (
      0 => 
      array (
        0 => ' eval(',
        1 => 'eval',
      ),
      1 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
    ),
  ),
  'statics/js/jquery-1.4.4.min.js' => 
  array (
    'func' => 
    array (
      0 => 
      array (
        0 => 'Eval(',
        1 => 'Eval',
      ),
      1 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      2 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      3 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      4 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      5 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      6 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      7 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      8 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      9 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      10 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      11 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      12 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      13 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      14 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      15 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      16 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      17 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      18 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      19 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      20 => 
      array (
        0 => 'Eval(',
        1 => 'Eval',
      ),
      21 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
    ),
  ),
  'statics/js/jquery.min.js' => 
  array (
    'func' => 
    array (
      0 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      1 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      2 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      3 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      4 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      5 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      6 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      7 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      8 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      9 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      10 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      11 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      12 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      13 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      14 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      15 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      16 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      17 => 
      array (
        0 => 'Eval(',
        1 => 'Eval',
      ),
      18 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      19 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      20 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      21 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      22 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      23 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      24 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      25 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      26 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      27 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      28 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      29 => 
      array (
        0 => 'Eval(',
        1 => 'Eval',
      ),
      30 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
    ),
  ),
  'statics/js/jquery.switchable.min.js' => 
  array (
    'func' => 
    array (
      0 => 
      array (
        0 => 'eval(',
        1 => 'eval',
      ),
    ),
  ),
  'statics/js/jquery.treetable.js' => 
  array (
    'func' => 
    array (
      0 => 
      array (
        0 => '
eval(',
        1 => 'eval',
      ),
    ),
  ),
  'statics/js/plupload/base.js' => 
  array (
    'func' => 
    array (
      0 => 
      array (
        0 => ' eval(',
        1 => 'eval',
      ),
    ),
  ),
  'statics/js/plupload/base_content.js' => 
  array (
    'func' => 
    array (
      0 => 
      array (
        0 => ' eval(',
        1 => 'eval',
      ),
    ),
  ),
  'statics/js/plupload/jquery.plupload.queue/jquery.plupload.queue.js' => 
  array (
    'func' => 
    array (
      0 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
    ),
  ),
  'statics/js/plupload/jquery.plupload.queue/jquery.plupload.queue.min.js' => 
  array (
    'func' => 
    array (
      0 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
    ),
  ),
  'statics/js/plupload/jquery.ui.plupload/jquery.ui.plupload.js' => 
  array (
    'func' => 
    array (
      0 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
    ),
  ),
  'statics/js/plupload/jquery.ui.plupload/jquery.ui.plupload.min.js' => 
  array (
    'func' => 
    array (
      0 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
    ),
  ),
  'statics/js/plupload/moxie.js' => 
  array (
    'func' => 
    array (
      0 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      1 => 
      array (
        0 => ' base64_decode(',
        1 => 'base64_decode',
      ),
      2 => 
      array (
        0 => ' exec(',
        1 => 'exec',
      ),
      3 => 
      array (
        0 => '	exec(',
        1 => 'exec',
      ),
      4 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      5 => 
      array (
        0 => ' exec(',
        1 => 'exec',
      ),
      6 => 
      array (
        0 => '	exec(',
        1 => 'exec',
      ),
      7 => 
      array (
        0 => '	exec(',
        1 => 'exec',
      ),
      8 => 
      array (
        0 => ' exec(',
        1 => 'exec',
      ),
      9 => 
      array (
        0 => '	exec(',
        1 => 'exec',
      ),
      10 => 
      array (
        0 => '	exec(',
        1 => 'exec',
      ),
      11 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      12 => 
      array (
        0 => ' exec(',
        1 => 'exec',
      ),
      13 => 
      array (
        0 => '	exec(',
        1 => 'exec',
      ),
      14 => 
      array (
        0 => '	exec(',
        1 => 'exec',
      ),
      15 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
    ),
  ),
  'statics/js/plupload/moxie.min.js' => 
  array (
    'func' => 
    array (
      0 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      1 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      2 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      3 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
    ),
  ),
  'statics/js/plupload/plupload.full.min.js' => 
  array (
    'func' => 
    array (
      0 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      1 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      2 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      3 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
    ),
  ),
  'statics/js/star_bak.js' => 
  array (
    'func' => 
    array (
      0 => 
      array (
        0 => ' eval(',
        1 => 'eval',
      ),
      1 => 
      array (
        0 => ' eval(',
        1 => 'eval',
      ),
      2 => 
      array (
        0 => '	eval(',
        1 => 'eval',
      ),
    ),
  ),
  'statics/js/swfobject.js' => 
  array (
    'func' => 
    array (
      0 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
    ),
  ),
  'statics/js/swfupload/swfupload.js' => 
  array (
    'func' => 
    array (
      0 => 
      array (
        0 => 'eval(',
        1 => 'eval',
      ),
    ),
  ),
  'statics/js/swfupload/unpack_swfupload.js' => 
  array (
    'func' => 
    array (
      0 => 
      array (
        0 => ' eval(',
        1 => 'eval',
      ),
      1 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
    ),
  ),
  'statics/js/uploadify/jquery.uploadify.js' => 
  array (
    'func' => 
    array (
      0 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      1 => 
      array (
        0 => '=eval(',
        1 => 'eval',
      ),
      2 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
    ),
  ),
  'statics/js/uploadify/jquery.uploadify.min.js' => 
  array (
    'func' => 
    array (
      0 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      1 => 
      array (
        0 => '=eval(',
        1 => 'eval',
      ),
      2 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
    ),
  ),
  'statics/js/video/html5.js' => 
  array (
    'func' => 
    array (
      0 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      1 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
    ),
  ),
  'statics/js/video/swfobject2.js' => 
  array (
    'func' => 
    array (
      0 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
    ),
  ),
  'statics/mooc/images/jquery.min.js' => 
  array (
    'func' => 
    array (
      0 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      1 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      2 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      3 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      4 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      5 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      6 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      7 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      8 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      9 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      10 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      11 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      12 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      13 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      14 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      15 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      16 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      17 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      18 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      19 => 
      array (
        0 => 'Eval(',
        1 => 'Eval',
      ),
      20 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      21 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      22 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      23 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      24 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      25 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      26 => 
      array (
        0 => 'Eval(',
        1 => 'Eval',
      ),
      27 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
    ),
  ),
  'statics/sina/js/common.js' => 
  array (
    'func' => 
    array (
      0 => 
      array (
        0 => ' eval(',
        1 => 'eval',
      ),
      1 => 
      array (
        0 => ' eval(',
        1 => 'eval',
      ),
      2 => 
      array (
        0 => ' eval(',
        1 => 'eval',
      ),
      3 => 
      array (
        0 => ' eval(',
        1 => 'eval',
      ),
      4 => 
      array (
        0 => '{eval(',
        1 => 'eval',
      ),
      5 => 
      array (
        0 => '{eval(',
        1 => 'eval',
      ),
      6 => 
      array (
        0 => '{eval(',
        1 => 'eval',
      ),
      7 => 
      array (
        0 => ' eval(',
        1 => 'eval',
      ),
      8 => 
      array (
        0 => ' eval(',
        1 => 'eval',
      ),
      9 => 
      array (
        0 => ' eval(',
        1 => 'eval',
      ),
      10 => 
      array (
        0 => ' eval(',
        1 => 'eval',
      ),
      11 => 
      array (
        0 => '
eval(',
        1 => 'eval',
      ),
      12 => 
      array (
        0 => ' eval(',
        1 => 'eval',
      ),
      13 => 
      array (
        0 => ' eval(',
        1 => 'eval',
      ),
      14 => 
      array (
        0 => ' eval(',
        1 => 'eval',
      ),
      15 => 
      array (
        0 => ' eval(',
        1 => 'eval',
      ),
    ),
  ),
  'statics/sina/js/gallary/jquery-1.7.1.min.js' => 
  array (
    'func' => 
    array (
      0 => 
      array (
        0 => 'Eval(',
        1 => 'Eval',
      ),
      1 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      2 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      3 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      4 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      5 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      6 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      7 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      8 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      9 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      10 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      11 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      12 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      13 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      14 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      15 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      16 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      17 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      18 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      19 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      20 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      21 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      22 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      23 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      24 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      25 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      26 => 
      array (
        0 => 'Eval(',
        1 => 'Eval',
      ),
      27 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
    ),
  ),
  'statics/sina/js/gallary/lof-slider.js' => 
  array (
    'func' => 
    array (
      0 => 
      array (
        0 => ' eval(',
        1 => 'eval',
      ),
      1 => 
      array (
        0 => ' eval(',
        1 => 'eval',
      ),
      2 => 
      array (
        0 => ' eval(',
        1 => 'eval',
      ),
    ),
  ),
  'statics/sina/js/jquery-1.4.1.min.js' => 
  array (
    'func' => 
    array (
      0 => 
      array (
        0 => 'Eval(',
        1 => 'Eval',
      ),
      1 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      2 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      3 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      4 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      5 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      6 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      7 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      8 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      9 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      10 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      11 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      12 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      13 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      14 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      15 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      16 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      17 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      18 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      19 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      20 => 
      array (
        0 => 'Eval(',
        1 => 'Eval',
      ),
      21 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
    ),
  ),
  'statics/sina/js/jquery-1.8.0.js' => 
  array (
    'func' => 
    array (
      0 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      1 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      2 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      3 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      4 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      5 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      6 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      7 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      8 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      9 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      10 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      11 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      12 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      13 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      14 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      15 => 
      array (
        0 => 'Eval(',
        1 => 'Eval',
      ),
      16 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      17 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      18 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      19 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      20 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      21 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      22 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      23 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      24 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      25 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      26 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      27 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      28 => 
      array (
        0 => 'Eval(',
        1 => 'Eval',
      ),
      29 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      30 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
    ),
  ),
  'statics/sina/js/sinalib.js' => 
  array (
    'func' => 
    array (
      0 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      1 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      2 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
    ),
  ),
  'statics/sina/js/sinalib.min.js' => 
  array (
    'func' => 
    array (
      0 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      1 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      2 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
    ),
  ),
  'statics/sina/js/ssologin.js' => 
  array (
    'func' => 
    array (
      0 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      1 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
    ),
  ),
  'statics/sina/js/suda_s_v851c.js' => 
  array (
    'func' => 
    array (
      0 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
    ),
  ),
  'test/jquery.form.js' => 
  array (
    'func' => 
    array (
      0 => 
      array (
        0 => 'Eval(',
        1 => 'Eval',
      ),
    ),
  ),
  'test/jquery.js' => 
  array (
    'func' => 
    array (
      0 => 
      array (
        0 => 'Eval(',
        1 => 'Eval',
      ),
      1 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      2 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      3 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      4 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      5 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      6 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      7 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      8 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      9 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      10 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      11 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      12 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      13 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      14 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      15 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      16 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      17 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      18 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      19 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
      20 => 
      array (
        0 => 'Eval(',
        1 => 'Eval',
      ),
      21 => 
      array (
        0 => '.exec(',
        1 => 'exec',
      ),
    ),
  ),
  'UploadHandler.php' => 
  array (
    'func' => 
    array (
      0 => 
      array (
        0 => ' exec(',
        1 => 'exec',
      ),
      1 => 
      array (
        0 => ' exec(',
        1 => 'exec',
      ),
    ),
  ),
  'redirec.php' => 
  array (
    'func' => 
    array (
      0 => 
      array (
        0 => ' base64_decode(',
        1 => 'base64_decode',
      ),
    ),
  ),
);
?>