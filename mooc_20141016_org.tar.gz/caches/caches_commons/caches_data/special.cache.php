<?php
return array (
  2 => 
  array (
    'id' => '2',
    'siteid' => '1',
    'title' => '儿歌',
    'url' => 'http://bordon.xicp.net/:9999/phpcms/html/special/erge/',
    'thumb' => 'http://bordon.xicp.net/:9999/phpcms/uploadfile/2013/1211/20131211073110382.jpg',
    'banner' => 'http://bordon.xicp.net/:9999/phpcms/uploadfile/2013/1211/20131211073110382.jpg',
    'ishtml' => '1',
  ),
  1 => 
  array (
    'id' => '1',
    'siteid' => '1',
    'title' => '人性的哲学与科学',
    'url' => 'bordon.xicp.net:9999/phpcms/html/special/yeludaxue/',
    'thumb' => 'bordon.xicp.net:9999/phpcms/uploadfile/2013/1210/20131210012519999.jpg',
    'banner' => 'bordon.xicp.net:9999/phpcms/uploadfile/2013/1210/20131210012519999.jpg',
    'ishtml' => '1',
  ),
);
?>