<?php
return array (
  'info_linkageid' => '3360',
  'info_cachetime' => '0',
  'img_contact' => '1',
  'multi_city' => '0',
  'info_catid' => '98',
  'info_modelid' => '14',
  'top_city' => '10',
  'top_city_posid' => '20',
  'top_zone' => '8',
  'top_zone_posid' => '21',
  'top_district' => '5',
  'top_district_posid' => '22',
);
?>
