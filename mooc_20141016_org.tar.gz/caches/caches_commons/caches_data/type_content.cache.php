<?php
return array (
  61 => 
  array (
    'typeid' => '61',
    'siteid' => '1',
    'module' => 'content',
    'modelid' => '0',
    'name' => 'test',
    'parentid' => '0',
    'typedir' => '',
    'url' => '',
    'template' => '',
    'listorder' => '0',
    'description' => '',
  ),
);
?>