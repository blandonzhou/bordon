<?php
return array (
  'beijing' => 
  array (
    'name' => '北京',
    'pinyin' => 'beijing',
    'linkageid' => '3361',
    'id' => '2',
  ),
);
?>
