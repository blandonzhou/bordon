<?php
return array (
  'fulltextenble' => '1',
  'relationenble' => '1',
  'suggestenable' => '1',
  'sphinxenable' => '0',
  'sphinxhost' => '10.228.134.102',
  'sphinxport' => '9312',
  1 => 
  array (
    'fulltextenble' => '1',
    'relationenble' => '0',
    'suggestenable' => '0',
    'sphinxenable' => '0',
    'sphinxhost' => '',
    'sphinxport' => '',
  ),
);
?>