<?php
return array (
  0 => 
  array (
    'typeid' => '59',
    'siteid' => '1',
    'module' => 'search',
    'modelid' => '11',
    'name' => '视频模型搜索',
    'parentid' => '0',
    'typedir' => 'content',
    'url' => '',
    'template' => '',
    'listorder' => '0',
    'description' => '视频模型搜索',
  ),
);
?>