<?php
return array (
  0 => 
  array (
    'id' => '287',
    'catid' => '17',
    'title' => '旋转门',
    'url' => 'http://bordon.xicp.net:9999/phpcms/index.php?m=content&c=index&a=show&catid=17&id=287',
    'username' => 'user1',
    'sysadd' => '0',
    'inputtime' => '1389632954',
    'status' => '99',
  ),
  1 => 
  array (
    'id' => '281',
    'catid' => '17',
    'title' => '李开复人民大学演讲-成功之道',
    'url' => 'http://bordon.xicp.net:9999/phpcms/index.php?m=content&c=index&a=show&catid=17&id=281',
    'username' => 'user1',
    'sysadd' => '0',
    'inputtime' => '1387678741',
    'status' => '99',
  ),
  2 => 
  array (
    'id' => '280',
    'catid' => '13',
    'title' => '小花瓣',
    'url' => 'http://bordon.xicp.net:9999/phpcms/index.php?m=content&c=index&a=show&catid=13&id=280',
    'username' => 'user1',
    'sysadd' => '0',
    'inputtime' => '1387632494',
    'status' => '99',
  ),
  3 => 
  array (
    'id' => '278',
    'catid' => '21',
    'title' => '小鸽子',
    'url' => 'http://bordon.xicp.net:9999/phpcms/index.php?m=content&c=index&a=show&catid=21&id=278',
    'username' => 'user1',
    'sysadd' => '0',
    'inputtime' => '1387630527',
    'status' => '99',
  ),
  4 => 
  array (
    'id' => '277',
    'catid' => '19',
    'title' => '外星车',
    'url' => 'http://bordon.xicp.net:9999/phpcms/index.php?m=content&c=index&a=show&catid=19&id=277',
    'username' => 'user1',
    'sysadd' => '0',
    'inputtime' => '1387630472',
    'status' => '99',
  ),
  5 => 
  array (
    'id' => '276',
    'catid' => '21',
    'title' => '熊猫帮忙',
    'url' => 'http://bordon.xicp.net:9999/phpcms/index.php?m=content&c=index&a=show&catid=21&id=276',
    'username' => 'user1',
    'sysadd' => '0',
    'inputtime' => '1387630407',
    'status' => '99',
  ),
  6 => 
  array (
    'id' => '275',
    'catid' => '25',
    'title' => '小棕熊 01',
    'url' => 'http://bordon.xicp.net:9999/phpcms/index.php?m=content&c=index&a=show&catid=25&id=275',
    'username' => 'user1',
    'sysadd' => '0',
    'inputtime' => '1387630349',
    'status' => '99',
  ),
  7 => 
  array (
    'id' => '274',
    'catid' => '21',
    'title' => 'AVSEQ17',
    'url' => 'http://bordon.xicp.net:9999/phpcms/index.php?m=content&c=index&a=show&catid=21&id=274',
    'username' => 'user1',
    'sysadd' => '0',
    'inputtime' => '1387629976',
    'status' => '99',
  ),
  8 => 
  array (
    'id' => '273',
    'catid' => '21',
    'title' => 'AVSEQ-05.DAT',
    'url' => 'http://bordon.xicp.net:9999/phpcms/index.php?m=content&c=index&a=show&catid=21&id=273',
    'username' => 'user1',
    'sysadd' => '0',
    'inputtime' => '1387629929',
    'status' => '99',
  ),
  9 => 
  array (
    'id' => '272',
    'catid' => '13',
    'title' => '小棕熊 10',
    'url' => 'http://bordon.xicp.net:9999/phpcms/index.php?m=content&c=index&a=show&catid=13&id=272',
    'username' => 'user1',
    'sysadd' => '0',
    'inputtime' => '1387629872',
    'status' => '99',
  ),
  10 => 
  array (
    'id' => '269',
    'catid' => '19',
    'title' => 'Extremists',
    'url' => 'http://bordon.xicp.net:9999/phpcms/index.php?m=content&c=index&a=show&catid=19&id=269',
    'username' => 'user1',
    'sysadd' => '0',
    'inputtime' => '1387591581',
    'status' => '99',
  ),
  11 => 
  array (
    'id' => '268',
    'catid' => '14',
    'title' => '010_576i',
    'url' => 'http://bordon.xicp.net:9999/phpcms/index.php?m=content&c=index&a=show&catid=14&id=268',
    'username' => 'user1',
    'sysadd' => '0',
    'inputtime' => '1387591470',
    'status' => '99',
  ),
  12 => 
  array (
    'id' => '262',
    'catid' => '13',
    'title' => '5.28.wmv',
    'url' => 'http://bordon.xicp.net:9999/phpcms/index.php?m=content&c=index&a=show&catid=13&id=262',
    'username' => 'user1',
    'sysadd' => '0',
    'inputtime' => '1387552028',
    'status' => '99',
  ),
  13 => 
  array (
    'id' => '261',
    'catid' => '13',
    'title' => '焊接知识',
    'url' => 'http://bordon.xicp.net:9999/phpcms/index.php?m=content&c=index&a=show&catid=13&id=261',
    'username' => 'user1',
    'sysadd' => '0',
    'inputtime' => '1387551993',
    'status' => '99',
  ),
);
?>
