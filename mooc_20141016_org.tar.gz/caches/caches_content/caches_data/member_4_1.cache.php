<?php
return array (
  0 => 
  array (
    'id' => '267',
    'catid' => '13',
    'title' => 'adfa',
    'url' => 'http://123.123.110.110:9999/phpcms/index.php?m=content&c=index&a=show&catid=13&id=267',
    'username' => 'asdfasdf',
    'sysadd' => '0',
    'inputtime' => '1387555972',
    'status' => '99',
  ),
  1 => 
  array (
    'id' => '266',
    'catid' => '13',
    'title' => 'adsf',
    'url' => 'http://123.123.110.110:9999/phpcms/index.php?m=content&c=index&a=show&catid=13&id=266',
    'username' => 'asdfasdf',
    'sysadd' => '0',
    'inputtime' => '1387555932',
    'status' => '99',
  ),
  2 => 
  array (
    'id' => '265',
    'catid' => '13',
    'title' => 'asdfas',
    'url' => 'http://123.123.110.110:9999/phpcms/index.php?m=content&c=index&a=show&catid=13&id=265',
    'username' => 'asdfasdf',
    'sysadd' => '0',
    'inputtime' => '1387555800',
    'status' => '99',
  ),
  3 => 
  array (
    'id' => '264',
    'catid' => '13',
    'title' => 'adfsaf',
    'url' => 'http://123.123.110.110:9999/phpcms/index.php?m=content&c=index&a=show&catid=13&id=264',
    'username' => 'asdfasdf',
    'sysadd' => '0',
    'inputtime' => '1387555634',
    'status' => '99',
  ),
);
?>
