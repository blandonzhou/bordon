<?php
return array (
  0 => 
  array (
    'id' => '271',
    'catid' => '13',
    'title' => '会员投入',
    'url' => 'http://123.123.110.110:9999/phpcms/index.php?m=content&c=index&a=show&catid=13&id=271',
    'username' => 'doraprince',
    'sysadd' => '0',
    'inputtime' => '1387627948',
    'status' => '99',
  ),
);
?>
