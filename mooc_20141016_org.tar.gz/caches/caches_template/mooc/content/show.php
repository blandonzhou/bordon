<?php defined('IN_PHPCMS') or exit('No permission resources.'); ?><?php include template("content","header"); ?>
<div class="blank_30"></div>
<div class="main-wrap mod-info-wrap cf ">
    <div class="mod-info fr">
        <h2 class="checked">热播课程</h2>
        <ul class="mod-hot ml10 mt15" id="mod-hot">
            <?php if(defined('IN_ADMIN')  && !defined('HTML')) {echo "<div class=\"admin_piao\" pc_action=\"content\" data=\"op=content&tag_md5=1caabdd2effea57c16f40f16de15a0a6&action=hits&catid=%24catid&num=10&order=views+DESC&return=list\"><a href=\"javascript:void(0)\" class=\"admin_piao_edit\">编辑</a>";}$content_tag = pc_base::load_app_class("content_tag", "content");if (method_exists($content_tag, 'hits')) {$list = $content_tag->hits(array('catid'=>$catid,'order'=>'views DESC','limit'=>'10',));}?>
            <?php $i=1?>
            <?php $n=1;if(is_array($list)) foreach($list AS $v) { ?>
            <li><span><?php echo $i;?></span><em class="aem"></em><a href="<?php echo $v['url'];?>"><?php echo $v['title'];?></a></li>
            <?php $i++?>
            <?php $n++;}unset($n); ?>
        </ul>
    </div>
    <div class="mod-list fl">
        <div class="inner">
            <div class="mod-list-title">
                <span>视频播放</span>
            </div>
            <div class="blank_15"></div>
            <div class="mod-list-cont">
                <h1><?php echo $title;?></h1>
                <div class="cont-info">
                    <span>播放：<span id="hits"><script language="JavaScript" src="<?php echo APP_PATH;?>api.php?op=count&id=<?php echo $id;?>&modelid=<?php echo $modelid;?>"></script></span>次</span>
                    <span><?php echo date('Y-m-d',strtotime($updatetime));?></span>
                    <span>关键字：<?php foreach($keywords as $k){echo $k.' ';}?></span>
                    <span>制作人：<?php echo $tea_name;?></span>
                </div>
                <div class="blank_20"></div>
                <div class="muke-video-play cf">
                	<!--视频播放区-->
                                        <div class="vd_playBox vd_fullPlayBox" style="position:static;"> 
                                            <!--宽屏加vd_fullPlayBox-->
                                            <div class="playBox" style="z-index:1400;position:relative;">
                                                <div id="video" style="width:730;height:430px;"><div id="a1"></div></div>
                                                <!--
                                                上面一行是播放器所在的容器名称，如果只调用flash播放器，可以只用<div id="a1"></div>
                                                -->
                                                <script type="text/javascript" src="<?php echo JS_PATH;?>ckplayer/ckplayer.js" charset="utf-8"></script>
                                                <script type="text/javascript">
                                            var flashvars={
                                                f:'<?php echo $video_url;?>',
                                                c:0,
                                                b:1
                                                };
                                            var params={bgcolor:'#FFF',allowFullScreen:true,allowScriptAccess:'always',wmode:'transparent'};
                                            CKobject.embedSWF('<?php echo JS_PATH;?>ckplayer/ckplayer.swf','a1','ckplayer_a1','730','430',flashvars,params);
                                            /*
                                            CKobject.embedSWF(播放器路径,容器id,播放器id/name,播放器宽,播放器高,flashvars的值,其它定义也可省略);
                                            下面三行是调用html5播放器用到的
                                            */
                                            var video=['<?php echo $video_url;?>->video/mp4','http://www.ckplayer.com/webm/0.webm->video/webm','http://www.ckplayer.com/webm/0.ogv->video/ogg'];
                                            var support=['iPad','iPhone','ios','android+false','msie10+false'];
                                            CKobject.embedHTML5('a1','ckplayer_a1',730,430,video,flashvars,support);                                             </script>
                                            </div>
                                        </div>

                                        <!--/视频播放区--> 
										<div>
										  <?php if($allow_comment && module_exists('comment')) { ?>
  <iframe src="<?php echo APP_PATH;?>index.php?m=comment&c=index&a=init&commentid=<?php echo id_encode("content_$catid",$id,$siteid);?>&iframe=1" width="100%" height="100%" id="comment_iframe" frameborder="0" scrolling="no"></iframe>
  <?php } ?>
										   </div>
                    
                </div>
            </div>
        </div>
    </div>
</div>
<?php include template("content","footer"); ?>


</body>
</html>
