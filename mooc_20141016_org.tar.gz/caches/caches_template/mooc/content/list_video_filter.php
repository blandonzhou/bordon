<?php defined('IN_PHPCMS') or exit('No permission resources.'); ?><?php include template("content","header"); ?>
<?php if(defined('IN_ADMIN')  && !defined('HTML')) {echo "<div class=\"admin_piao\" pc_action=\"get\" data=\"op=get&tag_md5=564431c0d07690d5b0f8e492c2f2540c&sql=select+%2A+from+v9_category+where+catid%3D%24catid&return=data&num=1\"><a href=\"javascript:void(0)\" class=\"admin_piao_edit\">编辑</a>";}pc_base::load_sys_class("get_model", "model", 0);$get_db = new get_model();$r = $get_db->sql_query("select * from v9_category where catid=$catid LIMIT 1");while(($s = $get_db->fetch_next()) != false) {$a[] = $s;}$data = $a;unset($a);?>
<?php $data=$data[0]?>
<?php
    switch($catid){
      case 193:$image=APP_PATH."statics/mooc/images/muke-bann2.jpg";
      break;
      case 192:$image=APP_PATH."statics/mooc/images/muke-bann3.jpg";
      break;      
      case 190:$image=APP_PATH."statics/mooc/images/muke-bann108.jpg";
      break;      
      case 189:$image=APP_PATH."statics/mooc/images/muke-bann.jpg";
      break;      
      case 191:$image=APP_PATH."statics/mooc/images/muke-bann18.jpg";
      break;
      default:$image=$data['image'];

    }
?>
<div  class="muke-bann-wrap2">

    <div  class="muke-bann">

        <img  src="<?php echo $image;?>" />

    </div>
</div>
	            <?php 
				$category_db = pc_base::load_model('category_model');
				$rr = $category_db->get_one(array('catid'=>$catid), 'arrchildid');
				$aa=$rr['arrchildid'];
				$bb=explode(",",$aa);
				?>
<div class="main-wrap">
    <div class="muke-inner">
        <div class="muke-screen-wrap cf">
            <div class="muke-cou-title"> <span class="fl">微视频资源</span> </div>
            <div class="muke-screen">
                <label>比赛：</label>
                <div class="screen-inner">  
                    <?php $n=1;if(is_array(filters('match',$modelid))) foreach(filters('match',$modelid) AS $r) { ?>
                    <?php echo $r['menu'];?>
                    <?php $n++;}unset($n); ?>
                </div>
            </div>
            <div class="muke-screen">
                <label>年份：</label>
                <div class="screen-inner"> 
                    <?php $n=1;if(is_array(filters('year',$modelid))) foreach(filters('year',$modelid) AS $r) { ?>
                    <?php echo $r['menu'];?>
                    <?php $n++;}unset($n); ?>
                </div>
            </div>
            <div class="muke-screen">
                <label>奖项：</label>
                <div class="screen-inner"> 
                    <?php $n=1;if(is_array(filters('prize',$modelid))) foreach(filters('prize',$modelid) AS $r) { ?>
                    <?php echo $r['menu'];?>
                    <?php $n++;}unset($n); ?>
                </div>
            </div>
        </div>
        <div class="blank_30"></div>
        <div class="muke-video cf">
            <div class="muke-cou-title"> <a>最新微视频</a> <a>最热微视频</a><a>最赞微视频</a></div>
            <div class="blank_10"></div>
            <div class="muke-video-list cf">
                <ul>  
                    <?php $sql = structure_filters_sql($modelid);?>
                    <?php $urlrule = makeurlrule()?>
                    <?php if(defined('IN_ADMIN')  && !defined('HTML')) {echo "<div class=\"admin_piao\" pc_action=\"content\" data=\"op=content&tag_md5=78f1db530bd305340de11c3fc6435ca5&action=lists&catid=%24catid&where=%24sql&order=updatetime+DESC&return=info&moreinfo=1&page=%24page&urlrule=%24urlrule&num=10\"><a href=\"javascript:void(0)\" class=\"admin_piao_edit\">编辑</a>";}$content_tag = pc_base::load_app_class("content_tag", "content");if (method_exists($content_tag, 'lists')) {$pagesize = 10;$page = intval($page) ? intval($page) : 1;if($page<=0){$page=1;}$offset = ($page - 1) * $pagesize;$content_total = $content_tag->count(array('catid'=>$catid,'where'=>$sql,'order'=>'updatetime DESC','moreinfo'=>'1','limit'=>$offset.",".$pagesize,'action'=>'lists',));$pages = pages($content_total, $page, $pagesize, $urlrule);$info = $content_tag->lists(array('catid'=>$catid,'where'=>$sql,'order'=>'updatetime DESC','moreinfo'=>'1','limit'=>$offset.",".$pagesize,'action'=>'lists',));}?>   
                    <?php $n=1;if(is_array($info)) foreach($info AS $v) { ?> 
                    <?php $img = explode('.',$v[local_video])?>
                    <?php $src = $img[0]?>    
                   
                    <li> <a class="fl" href="<?php echo $v['url'];?>"><img src="<?php echo $v['thumb'];?>" width="132" height="100"></a>
                        <div class="muke-video-info">
                            <h2><a href="<?php echo $v['url'];?>" title="<?php echo $v['title'];?>"><?php echo $v['title'];?></a></h2>
                            来源：<?php echo $CATEGORYS[$v['catid']]['catname'];?> <?php echo $v['tea_name'];?></br>
                            <?php $db = pc_base::load_model('hits_model'); $_r = $db->get_one(array('hitsid'=>'c-'.$modelid.'-'.$v[id])); $views = $_r[views]; ?>
                            播放：<?php echo $views;?></br>
                            发布时间：<?php echo date('Y-m-d',$v[inputtime]);?>
                        </div>
                    </li>
                    <?php $n++;}unset($n); ?>
                <?php if(defined('IN_ADMIN') && !defined('HTML')) {echo '</div>';}?>
                </ul>
                <div class="blank_30"></div>
                <div class="mr30">
                    <div class="page fr">
                        <?php echo $pages;?>
                    </div>
                </div>
                <div class="blank_10"></div>
            </div>
            
            <div class="muke-video-list cf">
                <ul>  
                <?php if(defined('IN_ADMIN')  && !defined('HTML')) {echo "<div class=\"admin_piao\" pc_action=\"get\" data=\"op=get&tag_md5=9befd8c15d05ffb2670148705605df0c&sql=select+v9_hits.views%2Cv9_video.%2A+from+v9_hits+left+join++v9_video+on+v9_hits.hitsid%3DCONCAT%28%27c-11-%27%2Cv9_video.id%29++where+v9_video.status%3D99+and+v9_video.catid%3D%24catid+order+by+v9_hits.views+DESC&urlrule=%24urlrule&num=20&return=hots\"><a href=\"javascript:void(0)\" class=\"admin_piao_edit\">编辑</a>";}pc_base::load_sys_class("get_model", "model", 0);$get_db = new get_model();$r = $get_db->sql_query("select v9_hits.views,v9_video.* from v9_hits left join  v9_video on v9_hits.hitsid=CONCAT('c-11-',v9_video.id)  where v9_video.status=99 and v9_video.catid=$catid order by v9_hits.views DESC LIMIT 20");while(($s = $get_db->fetch_next()) != false) {$a[] = $s;}$hots = $a;unset($a);?>      
                   <?php $n=1;if(is_array($hots)) foreach($hots AS $v) { ?> 
                    <li> <a class="fl" href="<?php echo $v['url'];?>"><img src="<?php echo $v['thumb'];?>" width="132" height="100"></a>
                        <div class="muke-video-info">
                            <h2><a href="<?php echo $v['url'];?>" title="<?php echo $v['title'];?>"><?php echo $v['title'];?></a></h2>
                            来源：<?php echo $CATEGORYS[$v['catid']]['catname'];?> <?php echo $v['tea_name'];?></br>
                            <?php $db = pc_base::load_model('hits_model'); $_r = $db->get_one(array('hitsid'=>'c-'.$modelid.'-'.$v[id])); $views = $_r[views]; ?>
                            播放：<?php echo $views;?></br>
                            发布时间：<?php echo date('Y-m-d',$v[inputtime]);?>
                        </div>
                    </li>
                    <?php $n++;}unset($n); ?>
                <?php if(defined('IN_ADMIN') && !defined('HTML')) {echo '</div>';}?>
                </ul>
            </div>
                        <div class="blank_30"></div>

           <div class="muke-video-list cf">
                <ul>
            <?php if(defined('IN_ADMIN')  && !defined('HTML')) {echo "<div class=\"admin_piao\" pc_action=\"get\" data=\"op=get&tag_md5=7a28bfe4155e6e652c02146bfa1e6675&sql=SELECT+%2A+FROM+v9_video+where+status%3D99+and+love+%3E+0++order+by+love+DESC&page=%24page&return=info&urlrule=%24urlrule\"><a href=\"javascript:void(0)\" class=\"admin_piao_edit\">编辑</a>";}pc_base::load_sys_class("get_model", "model", 0);$get_db = new get_model();$pagesize = 20;$page = intval($page) ? intval($page) : 1;if($page<=0){$page=1;}$offset = ($page - 1) * $pagesize;$r = $get_db->sql_query("SELECT COUNT(*) as count FROM  v9_video where status=99 and love > 0  order by love DESC");$s = $get_db->fetch_next();$pages=pages($s['count'], $page, $pagesize, $urlrule);$r = $get_db->sql_query("SELECT * FROM v9_video where status=99 and love > 0  order by love DESC LIMIT $offset,$pagesize");while(($s = $get_db->fetch_next()) != false) {$a[] = $s;}$info = $a;unset($a);?>      

                   <?php $n=1;if(is_array($info)) foreach($info AS $v) { ?> 
       <?php
	   if(in_array($v[catid],$bb)){
	   ?>
				    <?php $comment_tag = pc_base::load_app_class("comment_tag", "comment"); $comment_total = $comment_tag->count(array('commentid'=>'content_'.$v[catid].'-'.$v[id].'-1'));?>
                    <li> <a class="fl" href="<?php echo $v['url'];?>"><img src="<?php echo $v['thumb'];?>" width="132" height="100"></a>
                        <div class="muke-video-info">
                            <h2><a href="<?php echo $v['url'];?>" title="<?php echo $v['title'];?>"><?php echo $v['title'];?></a></h2>
                            来源：<?php echo $CATEGORYS[$v['catid']]['catname'];?> <?php echo $v['tea_name'];?></br>
                            <?php $db = pc_base::load_model('hits_model'); $_r = $db->get_one(array('hitsid'=>'c-'.$modelid.'-'.$v[id])); $views = $_r[views]; ?>
                            播放：<?php echo $views;?></br>评论：<?php if($comment_total) { ?><?php echo $comment_total;?><?php } else { ?>0<?php } ?>&nbsp;&nbsp;点赞：<?php echo $v['love'];?></br>
                            发布时间：<?php echo date('Y-m-d',$v[inputtime]);?>
                        </div>
                    </li>
	   <?php
	   }
	   ?>

                    <?php $n++;}unset($n); ?>
                <?php if(defined('IN_ADMIN') && !defined('HTML')) {echo '</div>';}?>
      </ul>
            </div>
                        <div class="blank_30"></div>
        </div>
    </div>
</div>
<?php include template("content","footer"); ?>
</body>
</html>
