<?php defined('IN_PHPCMS') or exit('No permission resources.'); ?><?php include template("content","header"); ?>
<?php if(defined('IN_ADMIN')  && !defined('HTML')) {echo "<div class=\"admin_piao\" pc_action=\"get\" data=\"op=get&tag_md5=564431c0d07690d5b0f8e492c2f2540c&sql=select+%2A+from+v9_category+where+catid%3D%24catid&return=data&num=1\"><a href=\"javascript:void(0)\" class=\"admin_piao_edit\">编辑</a>";}pc_base::load_sys_class("get_model", "model", 0);$get_db = new get_model();$r = $get_db->sql_query("select * from v9_category where catid=$catid LIMIT 1");while(($s = $get_db->fetch_next()) != false) {$a[] = $s;}$data = $a;unset($a);?>
<?php $data=$data[0]?>
<?php
    switch($catid){
      case 193:$image=APP_PATH."statics/mooc/images/muke-bann2.jpg";
      break;
      case 192:$image=APP_PATH."statics/mooc/images/muke-bann3.jpg";
      break;      
      case 190:$image=APP_PATH."statics/mooc/images/muke-bann108.jpg";
      break;      
      case 189:$image=APP_PATH."statics/mooc/images/muke-bann.jpg";
      break;      
      case 191:$image=APP_PATH."statics/mooc/images/muke-bann18.jpg";
      break;
      default:$image=$data['image'];

    }
?>
<div  class="muke-bann-wrap2">

    <div  class="muke-bann">

        <img  src="<?php echo $image;?>" />

    </div>
</div>
<div class="main-wrap">
    <div class="muke-inner">
        <div class="muke-screen-wrap cf">
            <div class="muke-cou-title"> <span class="fl">微视频资源</span> </div>
            <div class="muke-screen">
                <label>学段：</label>
                <div class="screen-inner">  
                    <?php $n=1;if(is_array(filters('xueduan',$modelid))) foreach(filters('xueduan',$modelid) AS $r) { ?>
                        <?php echo $r['menu'];?>
                    <?php $n++;}unset($n); ?>
                </div>
            </div>
            <div class="muke-screen">
                <label>科目：</label>
                <div class="screen-inner"> 
                    <?php $n=1;if(is_array(filters('xueke',$modelid))) foreach(filters('xueke',$modelid) AS $r) { ?>
                        <?php echo $r['menu'];?>
                    <?php $n++;}unset($n); ?>
                </div>
            </div>
            <div class="muke-screen">
                <label>年级：</label>
                <div class="screen-inner"> 
                    <?php $n=1;if(is_array(filters('nianji',$modelid))) foreach(filters('nianji',$modelid) AS $r) { ?>
                        <?php echo $r['menu'];?>
                    <?php $n++;}unset($n); ?>
                </div>
            </div>
        </div>
        <div class="blank_30"></div>
        <div class="muke-video cf">

            <div class="muke-cou-title"> <a>最新微视频</a> <a>最热微视频</a><a>最赞微视频</a></div>
            <div class="blank_10"></div>
            <div class="muke-video-list cf">
                <ul>  
            <?php $sql = structure_filters_sql($modelid);?>     

            <?php $urlrule = makeurlrule()?>


	            <?php 
				$category_db = pc_base::load_model('category_model');
				$rr = $category_db->get_one(array('catid'=>$catid), 'arrchildid');
				$aa=$rr['arrchildid'];
				$bb=explode(",",$aa);
				?>
              
            <?php if(defined('IN_ADMIN')  && !defined('HTML')) {echo "<div class=\"admin_piao\" pc_action=\"get\" data=\"op=get&tag_md5=b20cd488a1e25e604dbcbae6199a7271&sql=SELECT+%2A+FROM+v9_video+where+status%3D99+and+%24sql+order+by+inputtime+DESC&page=%24page&return=info&urlrule=%24urlrule\"><a href=\"javascript:void(0)\" class=\"admin_piao_edit\">编辑</a>";}pc_base::load_sys_class("get_model", "model", 0);$get_db = new get_model();$pagesize = 20;$page = intval($page) ? intval($page) : 1;if($page<=0){$page=1;}$offset = ($page - 1) * $pagesize;$r = $get_db->sql_query("SELECT COUNT(*) as count FROM  v9_video where status=99 and $sql order by inputtime DESC");$s = $get_db->fetch_next();$pages=pages($s['count'], $page, $pagesize, $urlrule);$r = $get_db->sql_query("SELECT * FROM v9_video where status=99 and $sql order by inputtime DESC LIMIT $offset,$pagesize");while(($s = $get_db->fetch_next()) != false) {$a[] = $s;}$info = $a;unset($a);?>      

                   <?php $n=1;if(is_array($info)) foreach($info AS $v) { ?> 
                    <li> <a class="fl" href="<?php echo $v['url'];?>"><img src="<?php echo $v['thumb'];?>" width="132" height="100"></a>
                        <div class="muke-video-info">
                            <h2><a href="<?php echo $v['url'];?>" title="<?php echo $v['title'];?>"><?php echo $v['title'];?></a></h2>
                            来源：<?php echo $CATEGORYS[$v['catid']]['catname'];?> <?php echo $v['tea_name'];?></br>
                            <?php $db = pc_base::load_model('hits_model'); $_r = $db->get_one(array('hitsid'=>'c-'.$modelid.'-'.$v[id])); $views = $_r[views]; ?>
                            播放：<?php echo $views;?></br>
                            发布时间：<?php echo date('Y-m-d',$v[inputtime]);?>
                        </div>
                    </li>
                    <?php $n++;}unset($n); ?>
                <?php if(defined('IN_ADMIN') && !defined('HTML')) {echo '</div>';}?>
                </ul>
                
                <div class="blank_30"></div>
                <div class="mr30">
                    <div class="page fr">
                        <?php echo $pages;?>
                    </div>
                </div>
                <div class="blank_10"></div>
            </div>

<!-- 最热视频 -->
             <div class="muke-video-list cf">
                <ul>  
			<?php if(defined('IN_ADMIN')  && !defined('HTML')) {echo "<div class=\"admin_piao\" pc_action=\"get\" data=\"op=get&tag_md5=f9c44fcf5e3d0b0d7b477c96c005b84d&sql=select+%2A+from+v9_hits+order+by+views+desc++limit+0%2C20+--&urlrule=%24urlrule&return=hots\"><a href=\"javascript:void(0)\" class=\"admin_piao_edit\">编辑</a>";}pc_base::load_sys_class("get_model", "model", 0);$get_db = new get_model();$r = $get_db->sql_query("select * from v9_hits order by views desc  limit 0,20 -- LIMIT 20");while(($s = $get_db->fetch_next()) != false) {$a[] = $s;}$hots = $a;unset($a);?>
			 <?php $n=1;if(is_array($hots)) foreach($hots AS $r) { ?>
			    <?php
				$h1=$r['hitsid'];
                $h2=explode("-",$h1);
				$hid=$h2[2];
				$hmid=$h2[1];  //视频模型id
				$hcatid=$r['catid'];
				$hviews=$r['views'];
				if(in_array($hcatid,$bb)){

				?>
										<?php if(defined('IN_ADMIN')  && !defined('HTML')) {echo "<div class=\"admin_piao\" pc_action=\"get\" data=\"op=get&tag_md5=3d3e63aed3c9eb491898501e93932a5d&sql=select+%2A+from+v9_video+where+id+%3D%24hid&return=vs\"><a href=\"javascript:void(0)\" class=\"admin_piao_edit\">编辑</a>";}pc_base::load_sys_class("get_model", "model", 0);$get_db = new get_model();$r = $get_db->sql_query("select * from v9_video where id =$hid LIMIT 20");while(($s = $get_db->fetch_next()) != false) {$a[] = $s;}$vs = $a;unset($a);?> 
							  
							  <?php $n=1;if(is_array($vs)) foreach($vs AS $s) { ?>
							  <?php
                                   $xx1=$s['title'];
								   $xx2=$s['url'];
								   $xx3=$s['thumb'];
								   $xx4=$s['inputtime'];
								   $xx5=$s['tea_name'];
								   ?>
							   <?php $n++;}unset($n); ?>
							<?php if(defined('IN_ADMIN') && !defined('HTML')) {echo '</div>';}?>
                    <li> <a class="fl" href="<?php echo $xx2;?>"><img src="<?php echo $xx3;?>" width="132" height="100"></a>
                        <div class="muke-video-info">
                            <h2><a href="<?php echo $xx2;?>" title="<?php echo $xx1;?>"><?php echo $xx1;?></a></h2>
                            来源：<?php echo $CATEGORYS[$hcatid]['catname'];?>&nbsp;<?php echo $xx5;?></br>
                            播放：<?php echo $hviews;?></br>
                            发布时间：<?php echo date('Y-m-d',$xx4);?>
                        </div>
                    </li>
				<?php
				}
				?>

							   <?php $n++;}unset($n); ?>
							<?php if(defined('IN_ADMIN') && !defined('HTML')) {echo '</div>';}?>
                </ul>
            </div>

            <div class="blank_30"></div>

			<!-- 最热视频结束 -->


    <div class="muke-video-list cf">
                <ul>
      <?php if(defined('IN_ADMIN')  && !defined('HTML')) {echo "<div class=\"admin_piao\" pc_action=\"get\" data=\"op=get&tag_md5=403d5d2768f1173115227a0973b12974&sql=select+%2A+from+v9_comment&urlrule=%24urlrule&num=20&return=hots2\"><a href=\"javascript:void(0)\" class=\"admin_piao_edit\">编辑</a>";}pc_base::load_sys_class("get_model", "model", 0);$get_db = new get_model();$r = $get_db->sql_query("select * from v9_comment LIMIT 20");while(($s = $get_db->fetch_next()) != false) {$a[] = $s;}$hots2 = $a;unset($a);?> 
	  
	  <?php $n=1;if(is_array($hots2)) foreach($hots2 AS $rh) { ?>
             <?php
			 $rb=str_replace("content_", "",$rh['commentid'] );
			 $rc=explode("-",$rb);
			 $rd=$rc[0];
			 $re=$rc[1];
			 if(in_array($rd,$bb)){
			 ?>
			   <?php $db = pc_base::load_model('hits_model');   $_r = $db->get_one(array('hitsid'=>'c-'.$modelid.'-'.$rc[1])); $views = $_r[views]; ?>
						<?php if(defined('IN_ADMIN')  && !defined('HTML')) {echo "<div class=\"admin_piao\" pc_action=\"get\" data=\"op=get&tag_md5=cb915b9791af4b7e100c4cba95c089f7&sql=select+%2A+from+v9_video+where+id+%3D%24re&return=vv\"><a href=\"javascript:void(0)\" class=\"admin_piao_edit\">编辑</a>";}pc_base::load_sys_class("get_model", "model", 0);$get_db = new get_model();$r = $get_db->sql_query("select * from v9_video where id =$re LIMIT 20");while(($s = $get_db->fetch_next()) != false) {$a[] = $s;}$vv = $a;unset($a);?> 
							  
							  <?php $n=1;if(is_array($vv)) foreach($vv AS $rv) { ?>
							  <?php
                                   $x1=$rv['title'];
								   $x2=$rv['url'];
								   $x3=$rv['thumb'];
								   $x4=$rv['inputtime'];
								   $x5=$rv['tea_name'];
								   ?>
							   <?php $n++;}unset($n); ?>
							<?php if(defined('IN_ADMIN') && !defined('HTML')) {echo '</div>';}?>
										   
                    <li> <a class="fl" href="<?php echo $x2;?>"><img src="<?php echo $x3;?>" width="132" height="100"></a>
                        <div class="muke-video-info">
                            <h2><a href="<?php echo $x2;?>" title="<?php echo $x1;?>"><?php echo $x1;?></a></h2>
                            来源：<?php echo $CATEGORYS[$rd]['catname'];?>&nbsp;<?php echo $x5;?></br>
                            播放：<?php echo $views;?></br>
							评论数：<?php echo $rh['total'];?>&nbsp;&nbsp;点赞数：
							<?php 
						$cid='content_'.$rd.'-'.$re.'-1';
	                     pc_base::load_sys_class("get_model", "model", 0);
						$get_db = new get_model();
						$result = $get_db->sql_query("SELECT count(*) as tt FROM `v9_comment_data_1` WHERE `commentid`='$cid' and direction=1");             
                         while ($rv = mysql_fetch_array($result)) {
						 echo $rv["tt"];
}
				?>
							</br>
                            发布时间：<?php echo date('Y-m-d',$x4);?>
                        </div>
                    </li>
			 <?php
			 }
			 ?>

   <?php $n++;}unset($n); ?>
<?php if(defined('IN_ADMIN') && !defined('HTML')) {echo '</div>';}?>
                </ul>
            </div>
                        <div class="blank_30"></div>
        </div>
    </div>
</div>
<?php include template("content","footer"); ?>
</body>
</html>
