<?php defined('IN_PHPCMS') or exit('No permission resources.'); ?><!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<title>华东师范大学慕课中心</title>
<link rel="stylesheet" type="text/css" href="<?php echo APP_PATH;?>statics/mooc/images/public.css">
<link rel="stylesheet" type="text/css" href="<?php echo APP_PATH;?>statics/mooc/images/muke.css">
<script type="text/javascript" src="<?php echo APP_PATH;?>statics/mooc/images/jquery.min.js"></script>
<script type="text/javascript" src="<?php echo APP_PATH;?>statics/mooc/images/faseSlider.js"></script>

<link href="<?php echo APP_PATH;?>statics/c20/reset.css"    rel="stylesheet" type="text/css" />
<link href="<?php echo APP_PATH;?>statics/c20/default_blue.css"    rel="stylesheet" type="text/css" />
</head>
<body>
<div class="muke-top-wrap">
  <div class="muke-top">
    <div class="blank_10"></div>

    <div class="muke-search fr">
      <form target="_blank" name="frm" method="get" action="<?php echo APP_PATH;?>index.php" id="form1">
        <input id="key" name="q" type="text" class="txt" value="请输入课程关键字" onblur="if(this.value=='') {this.value='请输入课程关键字';this.style.color='#999';}" onfocus="if(this.value=='请输入课程关键字') {this.value='';this.style.color='#333';}">
        <input type="hidden" name="m" value="content"/>
        <input type="hidden" name="c" value="mooc"/>
        <input type="hidden" name="a" value="search"/>
        <input class="btn" id="search" type="submit">
      </form>
    </div>
  </div>
</div>

<div id="header">
		<div>
			<a href="#" id="logo"><img src="<?php echo APP_PATH;?>statics/c20/images/logo5.png" alt="logo"></a>
			<ul>
				<li>
					<a href="index.php">首页</a>
				</li>
				<li>
					<a href="index.php?m=content&c=index&a=lists&catid=193">名校名栏</a>
				</li>
				<li >
					<a href="index.php?m=content&c=index&a=lists&catid=192">名师名课</a>
				</li>
				<li >
					<a href="index.php?m=content&c=index&a=lists&catid=190">获奖佳作</a>
				</li>
				<li >
					<a href="index.php?m=content&c=index&a=lists&catid=189">翻转课堂精选</a>
				</li>
				<li >
					<a href="index.php?m=content&c=mooc&a=lists&t=video&catid=191">微视频资源</a>
				</li>
                 <li >
					<a href="index.php?m=content&c=index&a=lists&t=school&catid=208">参与学校</a>
				</li>
                   <li >
					<a href="index.php?m=content&c=index&a=lists&catid=375">微视频大赛</a>
				</li>
				</li>
			</ul>
		</div>
	</div>
