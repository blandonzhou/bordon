<?php defined('IN_PHPCMS') or exit('No permission resources.'); ?><?php include template("content","header"); ?>
<div class="blank_30"></div>
<div class="main-wrap mod-info-wrap cf ">
    <div class="mod-info fr">
        <ul class="mod-info-menu">
            <?php if(defined('IN_ADMIN')  && !defined('HTML')) {echo "<div class=\"admin_piao\" pc_action=\"content\" data=\"op=content&tag_md5=1caabdd2effea57c16f40f16de15a0a6&action=hits&catid=%24catid&num=10&order=views+DESC&return=list\"><a href=\"javascript:void(0)\" class=\"admin_piao_edit\">编辑</a>";}$content_tag = pc_base::load_app_class("content_tag", "content");if (method_exists($content_tag, 'hits')) {$list = $content_tag->hits(array('catid'=>$catid,'order'=>'views DESC','limit'=>'10',));}?>
            <?php $i=1?>
            <?php $n=1;if(is_array($list)) foreach($list AS $v) { ?>
            <li <?php if($id==$v[id]) echo 'class="checked"';?>><a href="<?php echo $v['url'];?>"><?php echo $v['title'];?></a></li>
            <?php $i++?>
            <?php $n++;}unset($n); ?>
        </ul>
    </div>
    <div class="mod-list fl">
        <div class="inner">
            <div class="mod-list-title"><?php echo $title;?></div>
            <div class="blank_15"></div>
            <div class="mod-list-cont">
                <div class="node cf">
                 <?php echo $content;?>
                </div>
            </div>
        </div>
    </div>
</div>
<?php include template("content","footer"); ?>
</body>
</html>