<?php defined('IN_PHPCMS') or exit('No permission resources.'); ?><?php include template("content","header"); ?>
<div class="muke-bann-wrap2">
  <div class="muke-bann"><img  src="<?php echo APP_PATH;?>statics/mooc/images/muke-bann1.jpg" width="994" height="215"></div>
</div>
<div class="main-wrap">
 <div class="muke-inner">
  <div class="muke-screen-wrap cf">
   <div class="muke-cou-title">参与学校</div>
   <div class="muke-school-intr"> 所谓C20慕课联盟(高中)，其中的C即China(中国)，20是指20所国内著名高中;慕课(MOOCs)是英文"Massive Open Online Courses"的缩写，即大规模公开在线课程的简称。国内著名高中筹建慕课联盟，既是这些学校承担社会责任的需要，也是提升自身声望的需要。在基础教育领域，借助于慕课平台，教师可以实施"翻转课堂"，实现学校教学模式的变革，为拔尖创新人才的培养创造良好环境。 </div>
  </div>
  <div class="blank_30"></div>
  <div class="muke-video cf">
   <div class="muke-cou-title2"> 
                <?php if(defined('IN_ADMIN')  && !defined('HTML')) {echo "<div class=\"admin_piao\" pc_action=\"content\" data=\"op=content&tag_md5=5bcdeb2327c91f32b8772afd1359bc2a&action=category&catid=191&order=listorder+ASC\"><a href=\"javascript:void(0)\" class=\"admin_piao_edit\">编辑</a>";}$content_tag = pc_base::load_app_class("content_tag", "content");if (method_exists($content_tag, 'category')) {$data = $content_tag->category(array('catid'=>'191','order'=>'listorder ASC','limit'=>'20',));}?>
                    <?php $n=1;if(is_array($data)) foreach($data AS $v) { ?>
                    <a href="<?php echo $v['url'];?>" <?php if($catid==$v[catid]) echo 'class="checked"';?> ><?php echo $v['catname'];?></a>
                    <?php $n++;}unset($n); ?>
                <?php if(defined('IN_ADMIN') && !defined('HTML')) {echo '</div>';}?>
   </div>
   <div class="muke-video-list cf">
        <ul>  
        <?php if(defined('IN_ADMIN')  && !defined('HTML')) {echo "<div class=\"admin_piao\" pc_action=\"content\" data=\"op=content&tag_md5=da33f5b8593688abfdf6c5f4f81e65e7&action=category&catid=%24catid&order=listorder+ASC&num=100\"><a href=\"javascript:void(0)\" class=\"admin_piao_edit\">编辑</a>";}$content_tag = pc_base::load_app_class("content_tag", "content");if (method_exists($content_tag, 'category')) {$data = $content_tag->category(array('catid'=>$catid,'order'=>'listorder ASC','limit'=>'100',));}?>
            <?php $n=1;if(is_array($data)) foreach($data AS $v) { ?>
                    <li> <a class="fl" href="<?php echo $v['url'];?>"><img src="<?php echo $v['image'];?>" width="190" height="60"></a>
                        <div class="muke-video-info" style="width:234px">
                            <p><?php echo $v['description'];?></p>
                        </div>
                    </li>
            <?php $n++;}unset($n); ?>
        <?php if(defined('IN_ADMIN') && !defined('HTML')) {echo '</div>';}?>
        </ul>
   </div>
   <div class="blank_30"></div>
   <div class="mr30">
    <div class="page fr">
        <?php echo $pages;?>
    </div>
   </div>
   <div class="blank_30"></div>
  </div>
 </div>
</div>

<?php include template("content","footer"); ?>
</body>
</html>
