<?php defined('IN_PHPCMS') or exit('No permission resources.'); ?><div class="blank_30"></div>
<div class="muke-footer-wrap">
  <div id="muke-footer">
    <div class="footer-AboutUs">
    <?php if(defined('IN_ADMIN')  && !defined('HTML')) {echo "<div class=\"admin_piao\" pc_action=\"content\" data=\"op=content&tag_md5=5b81f06d32775159470507ec2a0de4ce&action=position&posid=23&order=listorder+DESC&num=4\"><a href=\"javascript:void(0)\" class=\"admin_piao_edit\">编辑</a>";}$content_tag = pc_base::load_app_class("content_tag", "content");if (method_exists($content_tag, 'position')) {$data = $content_tag->position(array('posid'=>'23','order'=>'listorder DESC','limit'=>'4',));}?>
        <?php $n=1; if(is_array($data)) foreach($data AS $key => $val) { ?>
            <a href="<?php echo $val['url'];?>"><?php echo $val['title'];?></a>
        <?php $n++;}unset($n); ?>
    <?php if(defined('IN_ADMIN') && !defined('HTML')) {echo '</div>';}?>
    </div>
    <div class="footer-left">
      <div class="footer-info"> Copyright ©2014 c20.org.cn　沪ICP备13031008号-1 </div>
    </div>
  </div>
</div>
<script type="text/javascript">

            $(function(){
		var tabTitle = ".muke-cou-title a";
		var tabContent = ".muke-video-list";
		$(tabTitle + ":first").addClass("checked");
		$(tabContent).not(":first").hide();
		$(tabTitle).unbind("click").bind("click", function(){
		$(this).siblings("a").removeClass("checked").end().addClass("checked");
		var index = $(tabTitle).index( $(this) );
		$(tabContent).eq(index).siblings(tabContent).hide().end().fadeIn(0);
		});
            });
            
            
		var aDiv = document.getElementById('muke-head');
		var aLi = aDiv.getElementsByTagName('li');
		for(var i=0;i<aLi.length;i++){
			aLi[i].onmouseover = function(){
				this.className = 'checked';
			}
			if(aLi[i].className==''){
				aLi[i].onmouseout = function(){
					this.className = '';
				}
			}
		} ;
                

	

</script>
