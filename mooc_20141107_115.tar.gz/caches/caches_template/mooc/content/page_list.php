<?php defined('IN_PHPCMS') or exit('No permission resources.'); ?><style type="text/css">
body{margin:0;padding:0;}
.ta{
font-family:'微软雅黑';
font-size:15px;
font-weight:700;
font-style:normal;
font-size-adjust:none;
color:#333 !important;
text-decoration:none;
line-height:24px;
text-align:left;

}
.vt{
	margin-top:5px;
	margin-left:10px;
font-family:'微软雅黑';
font-size:12px;
font-weight:400;
font-style:normal;
font-size-adjust:none;
color:rgb(51,​ 51,​ 51);
line-height:18px;
text-align:left;
	}
</style>



            <div class="paa">

		<?php
        if(isset($_GET['did']) && $_GET['did']!="" ){
     		$aa=$_GET['did'];   
        }else{
        $aa=337;   
        }

		?>
            <?php if(defined('IN_ADMIN')  && !defined('HTML')) {echo "<div class=\"admin_piao\" pc_action=\"content\" data=\"op=content&tag_md5=54d3e6ff508c617a66bd8e899b0e7a5a&action=lists&catid=%24aa&page=%24page&return=info&num=10\"><a href=\"javascript:void(0)\" class=\"admin_piao_edit\">编辑</a>";}$content_tag = pc_base::load_app_class("content_tag", "content");if (method_exists($content_tag, 'lists')) {$pagesize = 10;$page = intval($page) ? intval($page) : 1;if($page<=0){$page=1;}$offset = ($page - 1) * $pagesize;$content_total = $content_tag->count(array('catid'=>$aa,'limit'=>$offset.",".$pagesize,'action'=>'lists',));$pages = pages($content_total, $page, $pagesize, $urlrule);$info = $content_tag->lists(array('catid'=>$aa,'limit'=>$offset.",".$pagesize,'action'=>'lists',));}?>                 
           <?php $n=1;if(is_array($info)) foreach($info AS $v) { ?> 
            <div style="width: 300px; height: 120px; float: left; margin: 10px; border-bottom: 1px dashed #e7e7e7;"><table width="300" height="120" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td width="134" align="center" style="font-size: 14px;"><a class="fl" href="<?php echo $v['url'];?>" target="_blank"><img src="<?php echo $v['thumb'];?>" width="132" height="100"></td>
    <td valign="top"><div class="vt"><a href="<?php echo $v['url'];?>" title="<?php echo $v['title'];?>" class="ta" target="_blank"><?php echo $v['title'];?></a><br>
来源：<?php echo $v['school_name'];?> <?php echo $v['tea_name'];?><br>播放：<?php echo $views;?><br>发布时间：<?php echo date('Y-m-d',$v[inputtime]);?><br>点赞数：<?php echo $v['love'];?></div>      </td>
  </tr>
  <?php $db = pc_base::load_model('hits_model'); $_r = $db->get_one(array('hitsid'=>'c-11-'.$v[id])); $views = $_r[views]; ?>
  </table>
</div>
        <?php $n++;}unset($n); ?>
                    <?php if(defined('IN_ADMIN') && !defined('HTML')) {echo '</div>';}?>
                    <style>
                    .page a, .page span {
    background: none repeat scroll 0 0 #fff;
    border: 1px solid #ccc;
    border-radius: 5px;
    color: #777;
    font: 14px/20px arial;
    height: 20px;
    margin-left: 2px;
    overflow: hidden;
    padding: 3px 10px;
	text-decoration: none;
}
.page a:hover {
    background: none repeat scroll 0 0 #59bdff;
    color: #fff;
}
.page a.checked {
    background: none repeat scroll 0 0 rgba(0, 0, 0, 0);
    border: 0 none;
    font-weight: 600;
}
.page span {
    background: none repeat scroll 0 0 rgba(0, 0, 0, 0);
    border: 0 none;
    font-weight: 600;
}
.page a.checked:hover {
    background: none repeat scroll 0 0 rgba(0, 0, 0, 0);
    color: #fff;
}
.page a:link, .page a:visited, .page a:hover, .page a:active {
    color: #4e4e4e;
}
.page a:hover {
    color: #fff;
	text-decoration: underline;
}
.page a.checked:link, .page a.checked:visited, .page a.checked:hover, .page a.checked:active {
    color: #0874c4;
}
.page .page_no {
    background: none repeat scroll 0 0 #fff;
    color: #ccc;
}
.page .page_no:hover {
    background: none repeat scroll 0 0 #fff;
}
.page .page_no:link, .page .page_no:visited, .page .page_no:hover, .page .page_no:active {
    color: #ccc;
    cursor: text;
}
.page_skip {
    color: #777;
    float: left;
    padding-left: 15px;
}
.page_skip .skip_txt {
    border: 1px solid #ccc;
    border-radius: 4px;
    float: left;
    height: 20px;
    line-height: 20px;
    margin: 2px 5px 0;
    text-align: center;
    width: 40px;
}
.page_skip .skip_btn {
    background: none repeat scroll 0 0 #ebebeb;
    color: #777;
    cursor: pointer;
    font-size: 12px;
    height: 22px;
    line-height: 22px;
    margin-left: 5px;
    padding: 0 10px;
    width: auto;
}
.page_skip .skip_btn:hover {
    background: none repeat scroll 0 0 #ebebeb;
    color: #4e4e4e;
}
.page_skip span {
    float: left;
    line-height: 27px;
}

.fr {
    display: inline;
    float: right;
}
* {
    border: 0 none;
    margin: 0;
    padding: 0;
    word-break: break-all;
}
                    </style>
                                        <div style="width:600px; height:50px;margin-left:auto; margin-right:auto; margin-bottom:5px; line-height:50px">
             <div  class="page fr">           <?php echo $pages;?></div>
            </div>
        <div>





</body>
</html>
