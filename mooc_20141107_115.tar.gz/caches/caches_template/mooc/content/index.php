<?php defined('IN_PHPCMS') or exit('No permission resources.'); ?>﻿<!DOCTYPE HTML>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<title>华师慕课</title>
<meta property="qc:admins" content="167037261763206727636" />
</head>
<meta name="keywords" content="华师慕课,华东师范大学,慕课,慕课中心,C20,c20">
<meta name="description" content="华东师范大学慕课中心是以研究与开发基础教育、教师教育“慕课（大规模在线开放课程）”，并推动慕课在各领域高质量地得到实施的学术性组织。">
<link href="<?php echo APP_PATH;?>statics/c20/reset.css"    rel="stylesheet" type="text/css" />
<link href="<?php echo APP_PATH;?>statics/c20/muke.css"    rel="stylesheet" type="text/css" />
<link href="<?php echo APP_PATH;?>statics/c20/default_blue.css"    rel="stylesheet" type="text/css" />
<script type="text/javascript" src="<?php echo APP_PATH;?>statics/c20/jquery.min.js"   ></script>
<script type="text/javascript" src="<?php echo APP_PATH;?>statics/c20/s.js"   ></script>
<style>
</style>
<body>
<!--<div class="tbu">
  <div class="header-menu">
    <script type="text/javascript">document.write('<div style="float: right;"><iframe src="http://www.c20.org.cn/index.php?m=member&c=index&a=mini&forward='+encodeURIComponent(location.href)+'&siteid=1" allowTransparency="true"  width="180" height="50" frameborder="0" scrolling="no"></iframe></div>')</script>
    <div class="logo"><a href="index.htm"   ><img  src="logo2.png" width="269" height="51"></a></div>
    <nav class="menu">
      <ul>
        <li class="leaf"><a href="list-2-1.html"    title="">名校名栏</a></li>
        <li class="leaf"><a href="index.php-m=content&c=index&a=lists&catid=9&b=1.htm"    title="">名师名课</a></li>
        <li class="leaf"><a href="list-25-1.html"    title="">获奖佳作</a></li>
        <li class="leaf"><a href="index.php-m=content&c=index&a=lists&catid=20.htm"    title="">翻转课堂精选</a></li>
        <li class="leaf"><a href="index.php-m=member&c=content&a=publish.htm"    title="上传课程">微视频资源</a></li>
      </ul>
    </nav>
  </div>
</div>-->
<div id="header">
		<div>
			<a href="#" id="logo"><img src="<?php echo APP_PATH;?>statics/c20/images/logo5.png" alt="logo"></a>
			<ul>
				<li>
					<a href="index.php?m=content&c=index&a=lists&catid=193">名校名栏</a>
				</li>
				<li >
					<a href="index.php?m=content&c=index&a=lists&catid=192">名师名课</a>
				</li>
				<li >
					<a href="index.php?m=content&c=index&a=lists&catid=190">获奖佳作</a>
				</li>
				<li >
					<a href="index.php?m=content&c=index&a=lists&catid=189">翻转课堂精选</a>
				</li>
				<li >
					<a href="index.php?m=content&c=mooc&a=lists&t=video&catid=191">微视频资源</a>
				</li>
                 <li >
					<a href="index.php?m=content&c=index&a=lists&t=school&catid=208">参与学校</a>
				</li>
                   <li >
					<a href="index.php?m=content&c=index&a=lists&catid=375">微视频大赛</a>
				</li>
				</li>
			</ul>
		</div>
	</div>

<!--<div class="content-w">
  <div class="inside">
    <div><img src="homepage_composite_july-23-20132.jpg"    width="960" height="274"></div>
    <div class="i-button" style="padding-left:40px;"><a class="btn btn-blue" href="index.php-m=content&c=index&a=lists&catid=52.htm" >查看所有课程（小学，初中，高中）</a><a class="btn btn-blue" style="margin-left: 30px;" href="index.php-m=content&c=index&a=lists&catid=56.htm"   >师范生微视频大奖赛获奖作品</a></div>
  </div>
</div>-->
<div id="body">
  <div class="header">
			<div>
			  <div id="tagline">
			    <h1>华师慕课</h1>
					<h3> ——孩子身边的名师</h3>
			  </div>
			  <img src="<?php echo APP_PATH;?>statics/c20/images/拼图3.png" width="486" height="400">
			  <div class="section">
<h2> >>进入开放课程学习平台</h2>
					<!--<p>
						大规模开放课程
					</p>-->
					<a href="<?php echo APP_PATH;?>portal/site/newstudent" class="first">注册</a>
					<a href="<?php echo APP_PATH;?>portal/login">登录</a>
			  </div>
</div>
		</div>
		<!--<div class="body">
			<div>
				<div class="figure">
					<a href="campaigns.html"><img src="images/hands.jpg" alt="Image"></a>
					<h2><a href="campaigns.html">Campaigns</a></h2>
				</div>
				<div class="news">
					<h2>News &amp; Blog</h2>
					<ul>
						<li>
							<span class="date">Aug 00, 2012</span>
							<h3><a href="news.html">This is just a place holder</a></h3>
							<p>
								so you can see what the site would look like. This is just a place holder, so you can see what the site would look like.
							</p>
						</li>
						<li>
							<span class="date">Aug 00, 2012</span>
							<h3><a href="news.html">This is just a place holder</a></h3>
							<p>
								so you can see what the site would look like.
							</p>
						</li>
					</ul>
					<span class="link"><a href="news.html">Go To News</a></span>
				</div>
				<div class="help">
					<h2>How To Help</h2>
					<a href="getinvolved.html"><img src="images/finger.jpg" alt="Image"></a>
					<h3><a href="getinvolved.html">This is just a place holder</a></h3>
					<p>
						You can remove any link to our website from this website template, you&#39;re free to use this website template without linking back to us.
					</p>
					<span class="link"><a href="getinvolved.html">Get Involved</a></span>
				</div>
			</div>
		</div>-->
</div>

<div class="content-c" style="background-color:#fff;">
    <div class="rollBox" style="padding-top:20px; margin-left:auto; margin-right:auto;">
    <h3 style="	color: #000000;
	font-family: Microsoft YaHei ;
	font-size: 20px;
	letter-spacing:1px;
	font-weight: normal;
	line-height: 43px;
	margin: 0;">C20慕课联盟成员地方教育局</h3>
    <a href="javascript:;" onmousedown="ISL_GoDown()" onmouseup="ISL_StopDown()" onmouseout="ISL_StopDown()" class="img1" hidefocus="true"></a>
    <div class="Cont" id="ISL_Cont">
      <div class="ScrCont">
        <div id="List1">   
                    <div class="pic"><a href="#"   title="静安区教育局"><img src="<?php echo APP_PATH;?>statics/c20/images/jingan.jpg"    width="190" height="60"  alt="静安区教育局" /></a></div>
                    <div class="pic"><a href="#"    title="广州市教育局"><img src="<?php echo APP_PATH;?>statics/c20/images/guangzhou.jpg"    width="190" height="60"  alt="广州市教育局" /></a></div>
                    <div class="pic"><a href="#"    title="苏州教育局"><img src="<?php echo APP_PATH;?>statics/c20/images/suzhou.jpg"    width="190" height="60"  alt="苏州教育局" /></a></div>
                    <div class="pic"><a href="#"    title="长春教育局"><img src="<?php echo APP_PATH;?>statics/c20/images/changchun.jpg"    width="190" height="60"  alt="长春教育局" /></a></div>
                    <div class="pic"><a href="#"    title="沈阳教育局"><img src="<?php echo APP_PATH;?>statics/c20/images/shenyang.jpg"    width="190" height="60"  alt="沈阳教育局" /></a></div>
                    <div class="pic"><a href="#"    title="郑州市教育局"><img src="<?php echo APP_PATH;?>statics/c20/images/zhengzhou.jpg"    width="190" height="60"  alt="郑州市教育局" /></a></div>
                    <div class="pic"><a href="#"    title="青岛市教育局"><img src="<?php echo APP_PATH;?>statics/c20/images/qingdao.jpg"    width="190" height="60"  alt="青岛市教育局" /></a></div>
                    <div class="pic"><a href="#"    title="合肥市教育局"><img src="<?php echo APP_PATH;?>statics/c20/images/hefei.jpg"    width="190" height="60"  alt="合肥市教育局" /></a></div>
                    <div class="pic"><a href="#"    title="佳木斯教育局"><img src="<?php echo APP_PATH;?>statics/c20/images/jiamusi.jpg"    width="190" height="60"  alt="佳木斯教育局" /></a></div>
                    <div class="pic"><a href="#"    title="银川教育"><img src="<?php echo APP_PATH;?>statics/c20/images/yinchuan.jpg"    width="190" height="60"  alt="银川教育" /></a></div>
                    <div class="pic"><a href="#"    title="三亚市教育局"><img src="<?php echo APP_PATH;?>statics/c20/images/sanya.jpg"    width="190" height="60"  alt="三亚市教育局" /></a></div>
                    <div class="pic"><a href="#"    title="温州教育"><img src="<?php echo APP_PATH;?>statics/c20/images/wenzhou.jpg"    width="190" height="60"  alt="温州教育" /></a></div>
                    <div class="pic"><a href="#"    title="西安教育局"><img src="<?php echo APP_PATH;?>statics/c20/images/xian.jpg"    width="190" height="60"  alt="西安教育局" /></a></div>
                    <div class="pic"><a href="#"    title="乌鲁木齐教育局"><img src="<?php echo APP_PATH;?>statics/c20/images/wunumuqi.jpg"    width="190" height="60"  alt="乌鲁木齐教育局" /></a></div>
                    <div class="pic"><a href="#"    title="长沙教育局"><img src="<?php echo APP_PATH;?>statics/c20/images/changsha.jpg"    width="190" height="60"  alt="长沙教育局" /></a></div>
                     <div class="pic"><a href="#"    title="贵阳教育局"><img src="<?php echo APP_PATH;?>statics/c20/images/guiyang.jpg"    width="190" height="60"  alt="大同教育局.jpg" /></a></div>
              
                     </div>
        <div id="List2"></div>
      </div>
    </div>
    <a href="javascript:;"  onmousedown="ISL_GoUp()" onmouseup="ISL_StopUp()" onmouseout="ISL_StopUp()" class="img2" hidefocus="true"></a> </div>
    <!--成员校-->
    <div class="rollBox" style="margin-top:20px; margin-left:auto; margin-right:auto;">
    <h3 style="	color: #000000;
	font-family: Microsoft YaHei;
	font-size: 20px;
	letter-spacing:1px;
	font-weight: normal;
	line-height: 43px;
	margin: 0;">C20慕课联盟首批成员校</h3>
    <a href="javascript:;" onmousedown="ISL_GoDown2()" onmouseup="ISL_StopDown2()" onmouseout="ISL_StopDown2()" class="img1" hidefocus="true"></a>
    <div class="Cont" id="ISL_Cont2">
      <div class="ScrCont">
        <div id="List3">   
                    <div class="pic"><a href="#"    title="清华大学附属中学"><img src="<?php echo APP_PATH;?>statics/c20/images/20130830052600959.jpg"    width="190" height="60"  alt="清华大学附属中学" /></a></div>
                    <div class="pic"><a href="#"    title="华东师范大学第二附属中学"><img src="<?php echo APP_PATH;?>statics/c20/images/20130830064731691.jpg"    width="190" height="60"  alt="华东师范大学第二附属中学" /></a></div>
                    <div class="pic"><a href="#"    title="东北师范大学附属中学"><img src="<?php echo APP_PATH;?>statics/c20/images/20130830063412420.jpg"    width="190" height="60"  alt="东北师范大学附属中学" /></a></div>
                    <div class="pic"><a href="#"    title="西北师范大学附属中学"><img src="<?php echo APP_PATH;?>statics/c20/images/20130830063658418.jpg"    width="190" height="60"  alt="西北师范大学附属中学" /></a></div>
                    <div class="pic"><a href="#"    title="广东省中山纪念中学"><img src="<?php echo APP_PATH;?>statics/c20/images/20130830063201279.jpg"    width="190" height="60"  alt="广东省中山纪念中学" /></a></div>
                    <div class="pic"><a href="#"    title="贵州省贵阳市第一中学"><img src="<?php echo APP_PATH;?>statics/c20/images/20130830063222878.jpg"    width="190" height="60"  alt="贵州省贵阳市第一中学" /></a></div>
                    <div class="pic"><a href="#"    title="河南省郑州市外国语学校"><img src="<?php echo APP_PATH;?>statics/c20/images/20130830062153749.jpg"    width="190" height="60"  alt="河南省郑州市外国语学校" /></a></div>
                    <div class="pic"><a href="#"    title="黑龙江省哈尔滨市第三中学"><img src="<?php echo APP_PATH;?>statics/c20/images/20130830063241291.jpg"    width="190" height="60"  alt="黑龙江省哈尔滨市第三中学" /></a></div>
                    <div class="pic"><a href="#"    title="湖南省长沙市长郡中学"><img src="<?php echo APP_PATH;?>statics/c20/images/20130830063611246.jpg"    width="190" height="60"  alt="湖南省长沙市长郡中学" /></a></div>
                    <div class="pic"><a href="#"    title="江苏省南京市金陵中学"><img src="<?php echo APP_PATH;?>statics/c20/images/20130830063413204.jpg"    width="190" height="60"  alt="江苏省南京市金陵中学" /></a></div>
                    <div class="pic"><a href="#"    title="江苏省锡山高级中学"><img src="<?php echo APP_PATH;?>statics/c20/images/20130830063642906.jpg"    width="190" height="60"  alt="江苏省锡山高级中学" /></a></div>
                    <div class="pic"><a href="#"    title="山西省山西大学附属中学"><img src="<?php echo APP_PATH;?>statics/c20/images/20130830064935443.jpg"    width="190" height="60"  alt="山西省山西大学附属中学" /></a></div>
                    <div class="pic"><a href="#"    title="陕西西安交通大学附属中学"><img src="<?php echo APP_PATH;?>statics/c20/images/20130830063843891.jpg"    width="190" height="60"  alt="陕西西安交通大学附属中学" /></a></div>
                    <div class="pic"><a href="#"    title="浙江省宁波市镇海中学"><img src="<?php echo APP_PATH;?>statics/c20/images/20130830062108579.jpg"    width="190" height="60"  alt="浙江省宁波市镇海中学" /></a></div>
                    <div class="pic"><a href="#"    title="上海交通大学附属中学"><img src="<?php echo APP_PATH;?>statics/c20/images/20130830063750133.jpg"    width="190" height="60"  alt="上海交通大学附属中学" /></a></div>
                    <div class="pic"><a href="#"    title="上海市七宝中学"><img src="<?php echo APP_PATH;?>statics/c20/images/20130830062509432.jpg"    width="190" height="60"  alt="上海市七宝中学" /></a></div>
                    <div class="pic"><a href="#"    title="山东省青岛市第二中学"><img src="<?php echo APP_PATH;?>statics/c20/images/20131018031143552.jpg"    width="190" height="60"  alt="山东省青岛市第二中学" /></a></div>
                    <div class="pic"><a href="#"    title="福建省福州第一中学"><img src="<?php echo APP_PATH;?>statics/c20/images/20131018032404461.png"    width="190" height="60"  alt="福建省福州第一中学" /></a></div>
                    <div class="pic"><a href="#"    title="浙江省杭州学军中学"><img src="<?php echo APP_PATH;?>statics/c20/images/thumb_190_0_20131121041345352.jpg"    width="190" height="60"  alt="浙江省杭州学军中学" /></a></div>
                    <div class="pic"><a href="#"    title="辽宁省实验中学"><img src="<?php echo APP_PATH;?>statics/c20/images/thumb_190_0_20131127014329548.jpg"    width="190" height="60"  alt="辽宁省实验中学" /></a></div>
                     </div>
        <div id="List4"></div>
      </div>
    </div>
    <a href="javascript:;"  onmousedown="ISL_GoUp2()" onmouseup="ISL_StopUp2()" onmouseout="ISL_StopUp2()" class="img2" hidefocus="true"></a> </div>
  <div class="rollBox">  
    <div class="muke-list-wrap cf">
      <?php $i=0;?>
      <?php if(defined('IN_ADMIN')  && !defined('HTML')) {echo "<div class=\"admin_piao\" pc_action=\"content\" data=\"op=content&tag_md5=ed968f1e6661d88715b3b872bde85c08&action=category&catid=211&order=listorder+ASC&return=list\"><a href=\"javascript:void(0)\" class=\"admin_piao_edit\">编辑</a>";}$content_tag = pc_base::load_app_class("content_tag", "content");if (method_exists($content_tag, 'category')) {$list = $content_tag->category(array('catid'=>'211','order'=>'listorder ASC','limit'=>'20',));}?>
          <?php $n=1;if(is_array($list)) foreach($list AS $cat) { ?>
              <div class="muke-list <?php if($i%2) echo 'fr';else echo 'fl';?>">
                <div class="muke-title"> <span class="title-txt"><?php echo $cat['catname'];?></span> <a class="more" href="<?php echo $cat['url'];?>"></a> </div>
                <ul>
                    <?php if(defined('IN_ADMIN')  && !defined('HTML')) {echo "<div class=\"admin_piao\" pc_action=\"content\" data=\"op=content&tag_md5=10495770c836b3e37c1e05cb248ded6d&action=lists&catid=%24cat%5Bcatid%5D&order=listorder+DESC&num=5&return=article\"><a href=\"javascript:void(0)\" class=\"admin_piao_edit\">编辑</a>";}$content_tag = pc_base::load_app_class("content_tag", "content");if (method_exists($content_tag, 'lists')) {$article = $content_tag->lists(array('catid'=>$cat[catid],'order'=>'listorder DESC','limit'=>'5',));}?>
                        <?php $n=1;if(is_array($article)) foreach($article AS $a) { ?>
                          <li><span></span><a href="<?php echo $a['url'];?>" title="<?php echo $a['title'];?>"><?php echo $a['title'];?></a></li>
                        <?php $n++;}unset($n); ?>
                    <?php if(defined('IN_ADMIN') && !defined('HTML')) {echo '</div>';}?>   
                </ul>
              </div>
              <?php if($i%2){?>
              <div class="blank_30"></div>
              <?php }?>
              <?php $i++?>
          <?php $n++;}unset($n); ?>
      <?php if(defined('IN_ADMIN') && !defined('HTML')) {echo '</div>';}?>
    </div>
  </div>
    

  <!--<div class="home-page-tiles">
    <div class="col-right">
      <div class="home-page-tile-title">
        <h1>华师慕课：身边的名师</h1>
      </div>
      <div class="home-page-tile-description copy-base">　　 </div>
      <div class="home-page-see-all"><a class="btn btn-blue" href="index.php-m=content&c=index&a=lists&catid=9.htm"    title="查看所有课程">查看所有课程（小学，初中，高中）</a></div>
    </div>
    <div class="col-left">
      <div><a href="index.php-m=content&c=index&a=lists&catid=9.htm"   ><img src="edx_demo_herocourse_tombstone.jpg"    width="378" height="225"></a></div>
    </div>
  </div>-->
  <div class="index_news">
    <div class="indexnews_box">
      <div class="sec-header">
        <h2>相关链接</h2>
        <a href="#"    class="more" title=""></a> </div>
      <div class="sec-events-wrap" style="color: #085180;">        <ul>
                    <li>· <a href="http://www.ecnu.edu.cn" >华东师范大学</a></li>
                    <li>· <a href="http://www.c20mooc.cn">华东师范大学慕课中心</a></li>
                  </ul>
        </div>
    </div>
    <div class="indexnews_box mg20">
      <div class="sec-header">
        <h2>主办单位</h2>
        <a href="#"   class="more" title=""></a> </div>
      <div class="sec-events-wrap">        <ul>
                    <li>· <a href="#">华东师范大学慕课中心</a></li>
                    <li>· <a href="#">C20慕课联盟</a></li>
                  </ul>
        </div>
    </div>
    <div class="indexnews_box">
      <div class="sec-header">
        <h2>技术支持</h2>
       <a href="#"   class="more" title=""></a>  </div>
      <div class="sec-events-wrap">        <ul>
                    <li>· <a href="#" >华东师范大学信息化办公室</a></li>
                    
                    <li>· <a href="#" >华东师范大学慕课中心教育技术部</a>
                   </li>
                   
                  </ul>
        </div>
    </div>
  </div>
  <!--<div class="cent">    <p class="div10086" align="center">相关链接</p>
    <div id="announcement" class="announcement" onmouseover="if(!anncount) {clearTimeout(annst);annst = 0}" onmouseout="if(!annst) annst = setTimeout('announcementScroll()', anndelay);">
      <div id="announcementbody" class="announcementbody">
        <ul>
                              <li><a href="javascript:if(confirm(%27http://www.moe.edu.cn/  \n\nThis file was not retrieved by Teleport Pro, because it is addressed on a domain or path outside the boundaries set for its Starting Address.  \n\nDo you want to open it from the server?%27))window.location=%27http://www.moe.edu.cn/%27"    target="_blank" title="中华人民共和国教育部">中华人民共和国教育部</a></li>
                                        <li><a href="javascript:if(confirm(%27http://www.ecnu.edu.cn/  \n\nThis file was not retrieved by Teleport Pro, because it is addressed on a domain or path outside the boundaries set for its Starting Address.  \n\nDo you want to open it from the server?%27))window.location=%27http://www.ecnu.edu.cn/%27"    target="_blank" title="华东师范大学">华东师范大学</a></li>
                                        <li><a href="index.htm"    target="_blank" title="华东师范大学考试与评价研究院">华东师范大学考试与评价研究院</a></li>
                                        <li><a href="index.htm"    target="_blank" title="华东师范大学教育部中学校长培训中心">华东师范大学教育部中学校长培训中心</a></li>
                                        <li><a href="javascript:if(confirm(%27http://www.dedu.ecnu.edu.cn/  \n\nThis file was not retrieved by Teleport Pro, because it is addressed on a domain or path outside the boundaries set for its Starting Address.  \n\nDo you want to open it from the server?%27))window.location=%27http://www.dedu.ecnu.edu.cn/%27"    target="_blank" title="基础教育改革与发展研究所">基础教育改革与发展研究所</a></li>
                                        <li><a href="javascript:if(confirm(%27http://www.futurename.cn/  \n\nThis file was not retrieved by Teleport Pro, because it is addressed on a domain or path outside the boundaries set for its Starting Address.  \n\nDo you want to open it from the server?%27))window.location=%27http://www.futurename.cn/%27"    target="_blank" title="未名网">未名网</a></li>
                            </ul>
      </div>
    </div>
     </div>-->
</div>
<script type="text/javascript">

var anndelay = 3000;
var anncount = 0;
var annheight = 32;
var annst = 0;
function announcementScroll()
{
   if( ! annst)
   {
      document.getElementById('announcementbody').innerHTML += '<br style="clear: both" />' + document.getElementById('announcementbody').innerHTML;
      document.getElementById('announcementbody').scrollTop = 0;
      if(document.getElementById('announcementbody').scrollHeight > annheight * 3)
      {
         annst = setTimeout('announcementScroll()', anndelay);
      }
      else
      {
         document.getElementById('announcement').onmouseover = document.getElementById('announcement').onmouseout = null;
      }
      return;
   }
   if(anncount == annheight)
   {
      if(document.getElementById('announcementbody').scrollHeight - annheight <= document.getElementById('announcementbody').scrollTop)
      {
         document.getElementById('announcementbody').scrollTop = document.getElementById('announcementbody').scrollHeight / 2 - annheight;
      }
      anncount = 0;
      annst = setTimeout('announcementScroll()', anndelay);
   }
   else
   {
      document.getElementById('announcementbody').scrollTop ++ ;
      anncount ++ ;
      annst = setTimeout('announcementScroll()', 10);
   }
}
announcementScroll();
</script> 
<script language="javascript" type="text/javascript">
var Speed = 5; //速度(毫秒)
var Space = 5; //每次移动(px)
var PageWidth = 900; //翻页宽度
var fill = 0; //整体移位
var MoveLock = false;
var MoveTimeObj;
var Comp = 0;
var AutoPlayObj = null;
GetObj("List2").innerHTML = GetObj("List1").innerHTML;
GetObj('ISL_Cont').scrollLeft = fill;
GetObj("ISL_Cont").onmouseover = function(){clearInterval(AutoPlayObj);}
GetObj("ISL_Cont").onmouseout = function(){AutoPlay();}

GetObj("List4").innerHTML = GetObj("List3").innerHTML;
GetObj('ISL_Cont2').scrollLeft = fill;
GetObj("ISL_Cont2").onmouseover = function(){clearInterval(AutoPlayObj);}
GetObj("ISL_Cont2").onmouseout = function(){AutoPlay2();}

AutoPlay2();
AutoPlay();

function GetObj(objName){if(document.getElementById){return eval('document.getElementById("'+objName+'")')}else{return eval

('document.all.'+objName)}}
function AutoPlay(){ //自动滚动
clearInterval(AutoPlayObj);
AutoPlayObj = setInterval('ISL_GoDown();ISL_StopDown();',3000); //间隔时间
}
function AutoPlay2(){ //自动滚动
clearInterval(AutoPlayObj);
AutoPlayObj = setInterval('ISL_GoDown2();ISL_StopDown2();',3000); //间隔时间
}
function ISL_GoUp(){ //上翻开始
if(MoveLock) return;
clearInterval(AutoPlayObj);
MoveLock = true;
MoveTimeObj = setInterval('ISL_ScrUp();',Speed);
}
function ISL_GoUp2(){ //上翻开始
if(MoveLock) return;
clearInterval(AutoPlayObj);
MoveLock = true;
MoveTimeObj = setInterval('ISL_ScrUp2();',Speed);
}
function ISL_StopUp(){ //上翻停止
clearInterval(MoveTimeObj);
if(GetObj('ISL_Cont').scrollLeft % PageWidth - fill != 0){
Comp = fill - (GetObj('ISL_Cont').scrollLeft % PageWidth);
CompScr();
}else{
MoveLock = false;
}
AutoPlay();
}
function ISL_StopUp2(){ //上翻停止
clearInterval(MoveTimeObj);
if(GetObj('ISL_Cont2').scrollLeft % PageWidth - fill != 0){
Comp = fill - (GetObj('ISL_Cont2').scrollLeft % PageWidth);
CompScr2();
}else{
MoveLock = false;
}
AutoPlay2();
}
function ISL_ScrUp(){ //上翻动作
if(GetObj('ISL_Cont').scrollLeft <= 0){GetObj('ISL_Cont').scrollLeft = GetObj

('ISL_Cont').scrollLeft + GetObj('List1').offsetWidth}
GetObj('ISL_Cont').scrollLeft -= Space ;
}
function ISL_ScrUp2(){ //上翻动作
if(GetObj('ISL_Cont2').scrollLeft <= 0){GetObj('ISL_Cont2').scrollLeft = GetObj

('ISL_Cont2').scrollLeft + GetObj('List3').offsetWidth}
GetObj('ISL_Cont2').scrollLeft -= Space ;
}
function ISL_GoDown(){ //下翻
clearInterval(MoveTimeObj);
if(MoveLock) return;
clearInterval(AutoPlayObj);
MoveLock = true;
ISL_ScrDown();
MoveTimeObj = setInterval('ISL_ScrDown()',Speed);
}
function ISL_GoDown2(){ //下翻
clearInterval(MoveTimeObj);
if(MoveLock) return;
clearInterval(AutoPlayObj);
MoveLock = true;
ISL_ScrDown2();
MoveTimeObj = setInterval('ISL_ScrDown2()',Speed);
}
function ISL_StopDown(){ //下翻停止
clearInterval(MoveTimeObj);
if(GetObj('ISL_Cont').scrollLeft % PageWidth - fill != 0 ){
Comp = PageWidth - GetObj('ISL_Cont').scrollLeft % PageWidth + fill;
CompScr();
}else{
MoveLock = false;
}
AutoPlay();
}
function ISL_StopDown2(){ //下翻停止
clearInterval(MoveTimeObj);
if(GetObj('ISL_Cont2').scrollLeft % PageWidth - fill != 0 ){
Comp = PageWidth - GetObj('ISL_Cont2').scrollLeft % PageWidth + fill;
CompScr2();
}else{
MoveLock = false;
}
AutoPlay2();
}
function ISL_ScrDown(){ //下翻动作
if(GetObj('ISL_Cont').scrollLeft >= GetObj('List1').scrollWidth){GetObj('ISL_Cont').scrollLeft =

GetObj('ISL_Cont').scrollLeft - GetObj('List1').scrollWidth;}
GetObj('ISL_Cont').scrollLeft += Space ;
}
function ISL_ScrDown2(){ //下翻动作
if(GetObj('ISL_Cont2').scrollLeft >= GetObj('List3').scrollWidth){GetObj('ISL_Cont2').scrollLeft =

GetObj('ISL_Cont2').scrollLeft - GetObj('List3').scrollWidth;}
GetObj('ISL_Cont2').scrollLeft += Space ;
}
function CompScr(){
var num;
if(Comp == 0){MoveLock = false;return;}
if(Comp < 0){ //上翻
if(Comp < -Space){
   Comp += Space;
   num = Space;
}else{
   num = -Comp;
   Comp = 0;
}
GetObj('ISL_Cont').scrollLeft -= num;
setTimeout('CompScr()',Speed);
}else{ //下翻
if(Comp > Space){
   Comp -= Space;
   num = Space;
}else{
   num = Comp;
   Comp = 0;
}
GetObj('ISL_Cont').scrollLeft += num;
setTimeout('CompScr()',Speed);
}
}
function CompScr2(){
var num;
if(Comp == 0){MoveLock = false;return;}
if(Comp < 0){ //上翻
if(Comp < -Space){
   Comp += Space;
   num = Space;
}else{
   num = -Comp;
   Comp = 0;
}
GetObj('ISL_Cont2').scrollLeft -= num;
setTimeout('CompScr2()',Speed);
}else{ //下翻
if(Comp > Space){
   Comp -= Space;
   num = Space;
}else{
   num = Comp;
   Comp = 0;
}
GetObj('ISL_Cont2').scrollLeft += num;
setTimeout('CompScr2()',Speed);
}
}
</script> 

 
<div class="footer">
        <div class="footer-inside clearfix">
            <div class="left-col">
                <div class="links">
                    <ul>
                        <li class="links2">
                            <a href="index.php?m=content&c=index&a=show&catid=216&id=28"   >关于我们</a>
                        </li>
                        <li>
                            <a href="index.php?m=content&c=index&a=show&catid=216&id=33">加入我们</a>
                        </li>
                      <!--  <li>
                            <a href="index.php-m=content&c=index&a=lists&catid=21.htm"   >媒体链接</a>
                        </li>-->
                        <li>
                            <a href="index.php?m=content&c=index&a=show&catid=216&id=32"   >联系我们</a>
                        </li>
						<!--<li>
                            <a href="list-75-1.html"   >资源下载</a>
                        </li>-->
                    </ul>
                </div>
                <!--<div class="logo clearfix">
                    <div class="image">
                    </div>
                    <div class="description copy-meta">　　华东师范大学慕课中心成立于2013年9月。她是研究与开发基础教育、教师教育"慕课（大规模在线开放课程）"，并推动慕课在各领域高质量地得到实施的学术性组织。</div>
                </div>-->
            </div>
            <div class="right-col">
                <div class="social clearfix">
                    <div class="icon">
                        <a data-popup="true" href="#"><img src="<?php echo APP_PATH;?>statics/c20/images/social-google-plus.png"    /></a>
                    </div>
                    <div class="icon">
                        <a data-popup="true" href="#"><img src="<?php echo APP_PATH;?>statics/c20/images/ico_renren.png"    /></a>
                    </div>  
                    <div class="icon">
                        <a data-popup="true" href="#"><img src="<?php echo APP_PATH;?>statics/c20/images/ico_qq.png"    /></a>
                    </div>
                    <div class="icon">
                        <a data-popup="true" href="#" ><img src="<?php echo APP_PATH;?>statics/c20/images/ico_sina.png"    /></a>
                    </div>
                </div>
                <!--<div class="rights">
                    版权所有：华东师范大学慕课中心<br>
                    联系电话：021-62232116<br>
                    <a href="javascript:if(confirm(%27http://www.futurename.cn/  \n\nThis file was not retrieved by Teleport Pro, because it is addressed on a domain or path outside the boundaries set for its Starting Address.  \n\nDo you want to open it from the server?%27))window.location=%27http://www.futurename.cn/%27"    target="_blank">华东师范大学慕课中心教育技术部</a>提供技术支持
                </div>-->
				<!--<script type="text/javascript">
var _bdhmProtocol = (("https:" == document.location.protocol) ? " https://" : " http://");
document.write(unescape("%3Cscript src='" + _bdhmProtocol + "hm.baidu.com/h.js%3F181725d483cdf74ab19c2bcc387de8d1' type='text/javascript'%3E%3C/script%3E"));
</script>-->

            </div>
        </div>
    </div>
</body>
</html>
