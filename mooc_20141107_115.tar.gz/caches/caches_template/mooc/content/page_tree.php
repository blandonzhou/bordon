<?php defined('IN_PHPCMS') or exit('No permission resources.'); ?><?php include template("content","header"); ?>

<script type="text/javascript" src="<?php echo APP_PATH;?>statics/mooc/js/jquery.ztree.core-3.5.js"></script>
<link rel="stylesheet" href="<?php echo APP_PATH;?>statics/mooc/css/demo.css" type="text/css">
<link rel="stylesheet" href="<?php echo APP_PATH;?>statics/mooc/css/zTreeStyle.css" type="text/css">



<div class="blank_30"></div>
<div class="main-wrap mod-info-wrap cf ">
    <div class="mod-info">

    </div>
    <div class="mod-list fl" style="width:1000px">

<style type="text/css">
	
.paa {
    background: none repeat scroll 0 0 #fff;
    border-right: 1px solid #e7e7e7;
    height: 800px;
    width: 1000px;
    display: inline;
    float: left;
}
.ml {
width:300px;
height:780px;
margin:10px;

float:left;
}
.mr {
width:660px;
height:780px;
float:left;
margin-left:10px;
}
.paa a {
	color: #3C6E31;
	text-decoration: none;
}
.paa a:hover {
	color: #000;
text-decoration: none;
}
</style>
<SCRIPT type="text/javascript" >
  <!--
	var zTree;
	var demoIframe;

	var setting = {
		view: {
			dblClickExpand: false,
			showLine: true,
			selectedMulti: false
		},
		data: {
			simpleData: {
				enable:true,
				idKey: "id",
				pIdKey: "pId",
				rootPId: ""
			}
		},
		callback: {
			beforeClick: function(treeId, treeNode) {
				var zTree = $.fn.zTree.getZTreeObj("tree");
				if (treeNode.isParent) {
					zTree.expandNode(treeNode);
					return false;
				} else {
					demoIframe.attr("src",treeNode.file);
					return true;
				}
			}
		}
	};



	var zNodes =[



						<?php 

						display_tree(337);
						function display_tree($classid) {

						pc_base::load_sys_class("get_model", "model", 0);
						$get_db = new get_model();
						$result = $get_db->sql_query("SELECT * FROM v9_category WHERE parentid = '".$classid."'  ORDER BY listorder ASC");             
                         while ($rv = mysql_fetch_array($result)) {
           ?>
                     {id:<?php echo $rv['catid']?>, pId:<?php echo $rv['parentid']?>, name:"<?php echo $rv['catname']?>",<?php  if($rv['catid']==$rv['arrchildid']){ ?>file:"index.php?m=content&c=index&a=lists&catid=376&did=<?php echo $rv['catid']?>"<?php }else if($n==null){ ?>open:false<?php }?>},
		   <?php

        display_tree($rv['catid']);

        }
    }
?>
	];

	$(document).ready(function(){
		var t = $("#tree");
		t = $.fn.zTree.init(t, setting, zNodes);
		demoIframe = $("#right");
		demoIframe.bind("load", loadReady);
		var zTree = $.fn.zTree.getZTreeObj("tree");
		zTree.selectNode(zTree.getNodeByParam("id", 101));

	});

	function loadReady() {
		var bodyH = demoIframe.contents().find("body").get(0).scrollHeight,
		htmlH = demoIframe.contents().find("html").get(0).scrollHeight,
		maxH = Math.max(bodyH, htmlH), minH = Math.min(bodyH, htmlH),
		h = demoIframe.height() >= maxH ? minH:maxH ;
		if (h < 530) h = 530;
		demoIframe.height(h);
	}

  //-->
  </SCRIPT>
    <div class="paa" >

				<div class="ml">
						<div class="zTreeDemoBackground left">
							<ul id="tree" class="ztree"></ul>
						</div>
				</div>

				<div class="mr">
					<IFRAME ID="right" Name="right" FRAMEBORDER=0 SCROLLING=AUTO width=100%  height=780px SRC="index.php?m=content&c=index&a=lists&catid=376"></IFRAME>
				</div>


    </div>


    </div>
</div>


<?php include template("content","footer"); ?>
