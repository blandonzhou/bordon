<?php
return array (
  'title' => '分类信息',
  'style' => '1',
  'siteid' => '0',
  'data' => 
  array (
    3361 => 
    array (
      'linkageid' => '3361',
      'name' => '北京',
      'style' => '1',
      'parentid' => '0',
      'child' => '0',
      'arrchildid' => '',
      'keyid' => '3360',
      'listorder' => '0',
      'description' => '0',
      'setting' => NULL,
      'siteid' => '0',
    ),
    3362 => 
    array (
      'linkageid' => '3362',
      'name' => '朝阳',
      'style' => '1',
      'parentid' => '3361',
      'child' => '0',
      'arrchildid' => '',
      'keyid' => '3360',
      'listorder' => '0',
      'description' => '0',
      'setting' => NULL,
      'siteid' => '0',
    ),
    3363 => 
    array (
      'linkageid' => '3363',
      'name' => '国贸',
      'style' => '1',
      'parentid' => '3362',
      'child' => '0',
      'arrchildid' => '',
      'keyid' => '3360',
      'listorder' => '0',
      'description' => '0',
      'setting' => NULL,
      'siteid' => '0',
    ),
    3364 => 
    array (
      'linkageid' => '3364',
      'name' => 'CBD',
      'style' => '1',
      'parentid' => '3362',
      'child' => '0',
      'arrchildid' => '',
      'keyid' => '3360',
      'listorder' => '0',
      'description' => '0',
      'setting' => NULL,
      'siteid' => '0',
    ),
  ),
);
?>