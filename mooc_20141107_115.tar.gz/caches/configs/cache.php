<?php

return array (
	'file1' => array (
		'type' => 'file',
		'debug' => true,
		'pconnect' => 0,
		'autoconnect' => 0
		),
	'template' => array (
		'hostname' => 'localhost',
		'port' => 11211,
		'timeout' => 0,
		'type' => 'memcache',
		'debug' => true,
		'pconnect' => 0,
		'autoconnect' => 0
	)
);

?>
