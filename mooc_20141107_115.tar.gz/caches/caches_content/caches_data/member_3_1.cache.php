<?php
return array (
  0 => 
  array (
    'id' => '258',
    'catid' => '13',
    'title' => '中国电影报道',
    'url' => 'http://123.123.110.110:9999/phpcms/index.php?m=content&c=index&a=show&catid=13&id=258',
    'username' => 'aaa',
    'sysadd' => '0',
    'inputtime' => '1387548776',
    'status' => '99',
  ),
  1 => 
  array (
    'id' => '257',
    'catid' => '26',
    'title' => '08_huanleyeying',
    'url' => 'http://123.123.110.110:9999/phpcms/index.php?m=content&c=index&a=show&catid=26&id=257',
    'username' => 'aaa',
    'sysadd' => '0',
    'inputtime' => '1387548733',
    'status' => '99',
  ),
  2 => 
  array (
    'id' => '256',
    'catid' => '13',
    'title' => '[三只小鸟].S01E16',
    'url' => 'http://123.123.110.110:9999/phpcms/index.php?m=content&c=index&a=show&catid=13&id=256',
    'username' => 'aaa',
    'sysadd' => '0',
    'inputtime' => '1387548594',
    'status' => '99',
  ),
);
?>
