<?php
return array (
  'admin_email' => 'admin@yoursite.com',
  'maxloginfailedtimes' => '10',
  'minrefreshtime' => '2',
  'mail_type' => '1',
  'mail_server' => 'smtp.qq.com',
  'mail_port' => '25',
  'category_ajax' => '0',
  'mail_user' => 'admin@foxmail.com',
  'mail_auth' => '1',
  'mail_from' => 'admin@foxmail.com',
  'mail_password' => '',
  'errorlog_size' => '20',
);
?>