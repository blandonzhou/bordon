<?php
return array (
  1 => 
  array (
    'siteid' => '1',
    'name' => '默认站点',
    'dirname' => '',
    'domain' => 'http://42.121.254.160/mooc/',
    'site_title' => '医学资源站点',
    'keywords' => '医学多媒体',
    'description' => '医学多媒体资源网站',
    'release_point' => '',
    'default_style' => 'mooc',
    'template' => 'mooc',
    'setting' => 'array (
  \'upload_maxsize\' => \'204800\',
  \'upload_allowext\' => \'jpg|jpeg|gif|bmp|png|doc|docx|xls|xlsx|ppt|pptx|pdf|txt|rar|zip|swf|mp3|aac|wav\',
  \'watermark_enable\' => \'0\',
  \'watermark_minwidth\' => \'300\',
  \'watermark_minheight\' => \'300\',
  \'watermark_img\' => \'statics/images/water//mark.png\',
  \'watermark_pct\' => \'85\',
  \'watermark_quality\' => \'80\',
  \'watermark_pos\' => \'9\',
)',
    'uuid' => '8261f520-aa47-1031-97af-ab0e46332e4e',
    'url' => 'http://42.121.254.160/mooc/',
  ),
);
?>