<?php
return array (
  3361 => 
  array (
    'name' => '北京',
    'pinyin' => 'beijing',
    'linkageid' => '3361',
    'id' => '2',
  ),
);
?>
