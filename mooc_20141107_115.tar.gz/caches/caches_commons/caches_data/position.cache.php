<?php
return array (
  2 => 
  array (
    'posid' => '2',
    'modelid' => '0',
    'catid' => '0',
    'name' => '首页幻灯图推荐',
    'maxnum' => '20',
    'extention' => '',
    'listorder' => '4',
    'siteid' => '0',
    'thumb' => '',
  ),
  1 => 
  array (
    'posid' => '1',
    'modelid' => '0',
    'catid' => '0',
    'name' => '首页最新课程推荐',
    'maxnum' => '20',
    'extention' => '',
    'listorder' => '1',
    'siteid' => '0',
    'thumb' => '',
  ),
  18 => 
  array (
    'posid' => '18',
    'modelid' => '0',
    'catid' => '0',
    'name' => '最热课程推荐',
    'maxnum' => '20',
    'extention' => '',
    'listorder' => '0',
    'siteid' => '0',
    'thumb' => '',
  ),
  19 => 
  array (
    'posid' => '19',
    'modelid' => '0',
    'catid' => '0',
    'name' => '频道页今日更新',
    'maxnum' => '20',
    'extention' => '',
    'listorder' => '0',
    'siteid' => '0',
    'thumb' => '',
  ),
  20 => 
  array (
    'posid' => '20',
    'modelid' => '14',
    'catid' => '0',
    'name' => '城市置顶',
    'maxnum' => '20',
    'extention' => 'get_linkage({zone},getinfocache(\'info_linkageid\'), \'_\',4)',
    'listorder' => '0',
    'siteid' => '1',
    'thumb' => '',
  ),
  21 => 
  array (
    'posid' => '21',
    'modelid' => '14',
    'catid' => '0',
    'name' => '区域置顶',
    'maxnum' => '20',
    'extention' => 'get_linkage({zone},getinfocache(\'info_linkageid\'), \'_\',4)',
    'listorder' => '0',
    'siteid' => '1',
    'thumb' => '',
  ),
  22 => 
  array (
    'posid' => '22',
    'modelid' => '14',
    'catid' => '0',
    'name' => '商圈置顶',
    'maxnum' => '20',
    'extention' => 'get_linkage({zone},getinfocache(\'info_linkageid\'), \'_\',4)',
    'listorder' => '0',
    'siteid' => '1',
    'thumb' => '',
  ),
  23 => 
  array (
    'posid' => '23',
    'modelid' => '1',
    'catid' => '216',
    'name' => '首页底部',
    'maxnum' => '20',
    'extention' => '',
    'listorder' => '0',
    'siteid' => '1',
    'thumb' => '',
  ),
);
?>