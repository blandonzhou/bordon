<?php
return array (
  11 => 
  array (
    'typeid' => '59',
    'name' => '视频模型搜索',
    'sort' => '0',
  ),
);
?>